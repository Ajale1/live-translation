#!/bin/bash
# LiveTranslate — double-click installer for DaVinci Resolve STUDIO (macOS).
# If macOS blocks this file: right-click it -> Open -> Open.

cd "$(dirname "$0")"
clear
echo "==================================================="
echo "  LiveTranslate installer (Resolve Studio, macOS)"
echo "==================================================="
echo

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is not installed."
  echo "Get it from https://www.python.org/downloads/ then run this again."
  read -r -p "Press Enter to close..."
  exit 1
fi

if ! command -v npm >/dev/null 2>&1; then
  echo "Node.js is not installed (needed for the plugin panel)."
  echo "Get the LTS version from https://nodejs.org then run this again."
  read -r -p "Press Enter to close..."
  exit 1
fi

echo "You will be asked for your Mac password (typing is invisible - normal)."
echo
sudo python3 install-plugin.py
status=$?

echo
if [ $status -eq 0 ]; then
  echo "==================================================="
  echo "  DONE! Restart DaVinci Resolve, then open:"
  echo "  Workspace > Workflow Integrations > LiveTranslate"
  echo "==================================================="
else
  echo "Something went wrong above. Take a screenshot of this window"
  echo "and open an issue on the GitHub page."
fi
read -r -p "Press Enter to close..."
