"""Configuration for LiveTranslate.

Values can be overridden by a JSON file at:
  ~/.livetranslate/config.json
"""

import json
import os

DEFAULTS = {
    # --- Audio capture ---
    "sample_rate": 16000,          # Whisper native rate
    "block_ms": 30,                # capture block size in milliseconds
    "input_device": None,          # None = system default microphone

    # --- Voice activity / segmentation ---
    "vad_energy_threshold": 0.006, # RMS threshold for speech
    "silence_end_ms": 600,         # silence that closes a segment
    "max_segment_s": 8.0,          # force-close a segment after this long
    "partial_interval_s": 1.0,     # how often to emit partial transcripts

    # --- Transcription engine ---
    # "local"  -> faster-whisper on this machine (no network, no keys)
    # "openai" -> OpenAI API (needs OPENAI_API_KEY; lower CPU use)
    "engine": "local",
    "whisper_model": "small.en",   # tiny.en / base.en / small.en / medium.en
    "whisper_compute": "auto",     # auto / int8 / float16 / float32
    "openai_model": "whisper-1",

    # --- Translation ---
    # "local"  -> Argos Translate + NLLB-200 fallback (offline)
    # "openai" -> gpt-4o-mini via API
    "translator": "local",
    "source_language": "en",
    "target_languages": ["fr", "es"],

    # --- UI ---
    "font_family": "Helvetica",
    "font_size_source": 20,
    "font_size_translation": 26,
    "window_opacity": 0.92,
    "always_on_top": True,

    # --- Output ---
    "srt_dir": os.path.join(os.path.expanduser("~"), "LiveTranslate"),
}

_CONFIG_PATH = os.path.join(os.path.expanduser("~"), ".livetranslate", "config.json")


def load_config() -> dict:
    cfg = dict(DEFAULTS)
    try:
        with open(_CONFIG_PATH, "r", encoding="utf-8") as fh:
            cfg.update(json.load(fh))
    except (OSError, ValueError):
        pass
    return cfg


def save_config(cfg: dict) -> None:
    os.makedirs(os.path.dirname(_CONFIG_PATH), exist_ok=True)
    with open(_CONFIG_PATH, "w", encoding="utf-8") as fh:
        json.dump(cfg, fh, indent=2)
