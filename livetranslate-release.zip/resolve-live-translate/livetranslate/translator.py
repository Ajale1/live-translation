"""Translation engines: any source -> multiple targets.

Routing per target language, decided at session start:
  1. Argos Translate (light, offline) — used when it has the language pair,
     directly or pivoting through English.
  2. NLLB-200 (Meta's many-to-many model, offline) — used for everything
     Argos can't do: Hausa, Yoruba, Igbo, Swahili, Amharic, Somali, Shona,
     Lingala, Malagasy, and any other pair. Downloads once on first use.
  3. OpenAI (gpt-4o-mini) — used for ALL targets when cfg["translator"]
     == "openai" (needs OPENAI_API_KEY).

Public API (unchanged shape):
    translator = make_translator(cfg, log=print)
    translator.translate("hello") -> {"fr": "...", "ha": "...", ...}
"""

import json
import os

from .languages import CODE_TO_NAME, NLLB_CODE


class TranslatorError(RuntimeError):
    pass


# ---------------------------------------------------------------------------
# Argos
# ---------------------------------------------------------------------------
class ArgosEngine:
    def __init__(self, src: str, targets: set):
        import argostranslate.translate as atrans

        installed = atrans.get_installed_languages()
        src_lang = next((l for l in installed if l.code == src), None)
        if src_lang is None:
            raise TranslatorError(f"Argos package for '{src}' missing.")
        self._pipelines = {}
        for code in targets:
            dst = next((l for l in installed if l.code == code), None)
            pipeline = src_lang.get_translation(dst) if dst else None
            if pipeline is None:
                raise TranslatorError(f"Argos cannot translate {src}->{code}.")
            self._pipelines[code] = pipeline

    def translate_one(self, text: str, tgt: str) -> str:
        return self._pipelines[tgt].translate(text)


def argos_prepare_targets(src: str, wanted: list, log=None) -> set:
    """Ensure Argos packages for src->tgt (direct or via English pivot).
    Downloads missing packages when possible. Returns the set of targets
    Argos can serve; the rest fall through to NLLB."""
    def _log(m):
        if log:
            log(m)

    try:
        import argostranslate.package as apkg
    except ImportError:
        return set()

    def pairs_needed(tgt):
        if src == "en" or tgt == "en":
            return [(src, tgt)]
        return [(src, "en"), ("en", tgt)]  # pivot through English

    installed = {(p.from_code, p.to_code) for p in apkg.get_installed_packages()}
    available = []
    try:
        apkg.update_package_index()
        available = apkg.get_available_packages()
    except Exception:
        pass  # offline — only already-installed pairs usable

    ok = set()
    for tgt in wanted:
        good = True
        for pair in pairs_needed(tgt):
            if pair in installed:
                continue
            pkg = next(
                (p for p in available if (p.from_code, p.to_code) == pair),
                None,
            )
            if pkg is None:
                good = False
                break
            try:
                _log(f"Downloading translation package {pair[0]}->{pair[1]}…")
                apkg.install_from_path(pkg.download())
                installed.add(pair)
            except Exception:
                good = False
                break
        if good:
            ok.add(tgt)
    return ok


# ---------------------------------------------------------------------------
# NLLB-200 (transformers) — covers the African languages and any other pair
# ---------------------------------------------------------------------------
class NLLBEngine:
    MODEL = "facebook/nllb-200-distilled-600M"

    def __init__(self, src: str, log=None):
        def _log(m):
            if log:
                log(m)

        try:
            from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
        except ImportError:
            _log("Installing the NLLB translation engine (one time, large download)…")
            from .bootstrap import install_extra_deps

            # transformers>=4.53 avoids the 'chat_template.jinja 404' bug
            # older releases hit when downloading NLLB; numpy stays <2 to
            # match the compiled speech-engine binaries.
            install_extra_deps(
                ["torch", "transformers>=4.53", "huggingface_hub>=0.31",
                 "sentencepiece", "numpy<2"],
                log=_log,
            )
            from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

        _log("Loading NLLB-200 model (first use downloads ~1.2 GB)…")
        self.tok = AutoTokenizer.from_pretrained(
            self.MODEL, src_lang=NLLB_CODE[src]
        )
        self.model = AutoModelForSeq2SeqLM.from_pretrained(self.MODEL)
        self.model.eval()
        _log("NLLB-200 ready.")

    def translate_one(self, text: str, tgt: str) -> str:
        import torch

        inputs = self.tok(text, return_tensors="pt", truncation=True, max_length=512)
        with torch.no_grad():
            out = self.model.generate(
                **inputs,
                forced_bos_token_id=self.tok.convert_tokens_to_ids(NLLB_CODE[tgt]),
                max_length=256,
                num_beams=1,
            )
        return self.tok.batch_decode(out, skip_special_tokens=True)[0].strip()


# ---------------------------------------------------------------------------
# OpenAI (all targets in one call)
# ---------------------------------------------------------------------------
class OpenAIEngine:
    def __init__(self, src: str, targets: list):
        try:
            from openai import OpenAI
        except ImportError as exc:
            raise TranslatorError("The 'openai' package is not installed.") from exc
        if not os.environ.get("OPENAI_API_KEY"):
            raise TranslatorError("OPENAI_API_KEY is not set.")
        self.client = OpenAI()
        self.src = src
        self.targets = targets

    def translate_all(self, text: str) -> dict:
        names = ", ".join(
            f"{CODE_TO_NAME.get(c, c)} ({c})" for c in self.targets
        )
        resp = self.client.chat.completions.create(
            model="gpt-4o-mini",
            temperature=0,
            response_format={"type": "json_object"},
            messages=[
                {
                    "role": "system",
                    "content": (
                        f"Translate the user's {CODE_TO_NAME.get(self.src, self.src)} "
                        f"text into: {names}. Reply ONLY with a JSON object whose "
                        f"keys are the ISO codes {self.targets} and values are the "
                        "translations. Keep punctuation natural for spoken captions."
                    ),
                },
                {"role": "user", "content": text},
            ],
        )
        try:
            data = json.loads(resp.choices[0].message.content)
        except (ValueError, AttributeError):
            data = {}
        return {c: data.get(c, "") for c in self.targets}


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------
class TranslationRouter:
    def __init__(self, cfg: dict, log=None):
        self.src = cfg.get("source_language", "en")
        self.targets = [
            t for t in cfg.get("target_languages", ["fr", "es"]) if t != self.src
        ]
        if not self.targets:
            raise TranslatorError("Pick at least one target language different from the source.")

        for code in [self.src] + self.targets:
            if code not in NLLB_CODE:
                raise TranslatorError(f"Unknown language code: {code}")

        self._openai = None
        self._argos = None
        self._nllb = None
        self._route = {}

        if cfg.get("translator", "local") == "openai":
            self._openai = OpenAIEngine(self.src, self.targets)
            return

        argos_ok = argos_prepare_targets(self.src, self.targets, log)
        if argos_ok:
            try:
                self._argos = ArgosEngine(self.src, argos_ok)
            except TranslatorError:
                argos_ok = set()

        rest = [t for t in self.targets if t not in argos_ok]
        if rest:
            self._nllb = NLLBEngine(self.src, log)

        for t in self.targets:
            self._route[t] = self._argos if t in argos_ok else self._nllb

    def translate(self, text: str) -> dict:
        if self._openai:
            return self._openai.translate_all(text)
        out = {}
        for tgt, engine in self._route.items():
            try:
                out[tgt] = engine.translate_one(text, tgt)
            except Exception:
                out[tgt] = ""
        return out


def make_translator(cfg: dict, log=None):
    return TranslationRouter(cfg, log=log)
