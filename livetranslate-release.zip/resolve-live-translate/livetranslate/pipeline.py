"""The real-time pipeline: mic -> transcribe -> translate -> UI events.

Also records timed caption entries so the session can be exported as SRT
(one file per language) and pushed into the Resolve timeline.
"""

import queue
import threading
import time

from .audio_capture import MicSegmenter
from .transcriber import make_transcriber
from .translator import make_translator


class CaptionEntry:
    __slots__ = ("start", "end", "text", "translations")

    def __init__(self, start, end, text, translations):
        self.start = start          # seconds since session start
        self.end = end
        self.text = text            # English
        self.translations = translations  # {"fr": ..., "es": ...}


class LivePipeline:
    """Runs capture + STT + MT on worker threads.

    UI events are pushed to ``ui_queue`` as dicts:
      {"kind": "status",  "text": str}
      {"kind": "level",   "value": float}
      {"kind": "partial", "src": str}
      {"kind": "final",   "src": str, "tr": {lang_code: str, ...}}
      {"kind": "error",   "text": str}
    """

    def __init__(self, cfg: dict, ui_queue: "queue.Queue"):
        self.cfg = cfg
        self.ui = ui_queue
        self.audio_q: "queue.Queue" = queue.Queue()
        self.entries: list[CaptionEntry] = []
        self._segmenter = None
        self._transcriber = None
        self._translator = None
        self._stop = threading.Event()
        self._threads = []
        self._t0 = None
        self._pending_start = None  # start time of the segment being decoded

    # ------------------------------------------------------------------
    def start(self):
        self._stop.clear()
        self.entries = []
        self._t0 = time.monotonic()

        self.ui.put({"kind": "status", "text": "Loading models…"})
        try:
            self._transcriber = make_transcriber(self.cfg)
            self._translator = make_translator(
                self.cfg,
                log=lambda t: self.ui.put({"kind": "status", "text": t}),
            )
        except Exception as exc:  # surfaced in the UI, not swallowed
            self.ui.put({"kind": "error", "text": str(exc)})
            return False

        self._segmenter = MicSegmenter(self.cfg, self.audio_q)
        self._segmenter.start()

        worker = threading.Thread(target=self._consume, daemon=True)
        worker.start()
        meter = threading.Thread(target=self._meter, daemon=True)
        meter.start()
        self._threads = [worker, meter]

        self.ui.put({"kind": "status", "text": "Listening — speak in English"})
        return True

    def stop(self):
        self._stop.set()
        if self._segmenter:
            self._segmenter.stop()
        for t in self._threads:
            t.join(timeout=5)
        self.ui.put({"kind": "status", "text": "Stopped"})

    # ------------------------------------------------------------------
    def _meter(self):
        while not self._stop.is_set():
            if self._segmenter:
                self.ui.put({"kind": "level", "value": self._segmenter.level})
            time.sleep(0.1)

    def _consume(self):
        sr = self.cfg["sample_rate"]
        while not self._stop.is_set():
            try:
                kind, audio = self.audio_q.get(timeout=0.25)
            except queue.Empty:
                continue

            now = time.monotonic() - self._t0
            duration = len(audio) / sr

            try:
                text = self._transcriber.transcribe(audio)
            except Exception as exc:
                self.ui.put({"kind": "error", "text": f"STT error: {exc}"})
                continue
            if not text:
                continue

            if kind == "partial":
                self.ui.put({"kind": "partial", "src": text})
                continue

            # final segment: translate and record
            try:
                tr = self._translator.translate(text)
            except Exception as exc:
                self.ui.put({"kind": "error", "text": f"MT error: {exc}"})
                tr = {c: "" for c in self.cfg["target_languages"]}

            entry = CaptionEntry(
                start=max(0.0, now - duration),
                end=now,
                text=text,
                translations=tr,
            )
            self.entries.append(entry)

            self.ui.put({"kind": "final", "src": text, "tr": tr})
