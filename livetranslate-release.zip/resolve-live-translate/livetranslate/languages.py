"""Language catalog for LiveTranslate.

Each entry: (iso_code, English name, NLLB/FLORES code, whisper_transcribable)

whisper_transcribable == False means the language can be a translation
TARGET but not the spoken SOURCE (Whisper has no speech recognition for it).
"""

LANGUAGES = [
    ("en", "English", "eng_Latn", True),
    ("fr", "French", "fra_Latn", True),
    ("es", "Spanish", "spa_Latn", True),
    ("ar", "Arabic", "arb_Arab", True),
    ("pt", "Portuguese", "por_Latn", True),
    ("de", "German", "deu_Latn", True),
    ("it", "Italian", "ita_Latn", True),
    ("nl", "Dutch", "nld_Latn", True),
    ("ru", "Russian", "rus_Cyrl", True),
    ("zh", "Chinese (Simplified)", "zho_Hans", True),
    ("ja", "Japanese", "jpn_Jpan", True),
    ("ko", "Korean", "kor_Hang", True),
    ("hi", "Hindi", "hin_Deva", True),
    ("tr", "Turkish", "tur_Latn", True),
    ("pl", "Polish", "pol_Latn", True),
    ("uk", "Ukrainian", "ukr_Cyrl", True),
    ("vi", "Vietnamese", "vie_Latn", True),
    ("id", "Indonesian", "ind_Latn", True),
    ("fa", "Persian", "pes_Arab", True),
    ("he", "Hebrew", "heb_Hebr", True),
    # --- African languages ---
    ("ha", "Hausa", "hau_Latn", True),
    ("yo", "Yoruba", "yor_Latn", True),
    ("ig", "Igbo", "ibo_Latn", False),  # target-only: Whisper cannot transcribe spoken Igbo
    ("sw", "Swahili", "swh_Latn", True),
    ("am", "Amharic", "amh_Ethi", True),
    ("so", "Somali", "som_Latn", True),
    ("sn", "Shona", "sna_Latn", True),
    ("ln", "Lingala", "lin_Latn", True),
    ("af", "Afrikaans", "afr_Latn", True),
    ("mg", "Malagasy", "plt_Latn", True),
]

CODE_TO_NAME = {c: n for c, n, _, _ in LANGUAGES}
NLLB_CODE = {c: f for c, _, f, _ in LANGUAGES}
TRANSCRIBABLE = {c for c, _, _, ok in LANGUAGES if ok}
ALL_CODES = [c for c, _, _, _ in LANGUAGES]


def catalog():
    """JSON-friendly list for the UIs."""
    return [
        {"code": c, "name": n, "transcribable": ok}
        for c, n, _, ok in LANGUAGES
    ]


def name_of(code: str) -> str:
    return CODE_TO_NAME.get(code, code)
