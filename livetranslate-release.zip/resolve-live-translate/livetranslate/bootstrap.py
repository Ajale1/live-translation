"""First-run self-installer and launcher.

Called by the single-file LiveTranslate.py after it has extracted the
embedded package. Uses ONLY the Python standard library until the
dependencies it installs become importable.

Flow:
  ensure_ready()
    ├─ everything already installed?  -> launch the caption app
    └─ else show a Tk setup window and, on a worker thread:
         1. pip install deps into ~/.livetranslate/lib (private, no admin)
         2. download Argos en->fr / en->es translation packages
         3. cache the Whisper model
         4. copy this script into Resolve's Scripts/Utility folder
       then write a marker file and launch the app.
"""

import importlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import traceback

LT_HOME = os.path.join(os.path.expanduser("~"), ".livetranslate")
LIB_DIR = os.path.join(LT_HOME, "lib")
MARKER = os.path.join(LT_HOME, "setup-complete.json")

# (import name, pip name)
DEPS = [
    ("numpy", "numpy<2"),
    ("sounddevice", "sounddevice"),
    ("faster_whisper", "faster-whisper"),
    ("argostranslate", "argostranslate"),
]


# ----------------------------------------------------------------------
# Environment checks
# ----------------------------------------------------------------------
def _ensure_lib_on_path():
    if LIB_DIR not in sys.path:
        sys.path.insert(0, LIB_DIR)


def missing_deps() -> list:
    _ensure_lib_on_path()
    importlib.invalidate_caches()
    return [pip for mod, pip in DEPS if importlib.util.find_spec(mod) is None]


def setup_complete() -> bool:
    return os.path.exists(MARKER) and not missing_deps()


def resolve_scripts_dir() -> str:
    if sys.platform == "darwin":
        return os.path.expanduser(
            "~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Scripts/Utility"
        )
    if sys.platform.startswith("win"):
        return os.path.join(
            os.environ.get("APPDATA", ""),
            "Blackmagic Design",
            "DaVinci Resolve",
            "Support",
            "Fusion",
            "Scripts",
            "Utility",
        )
    return os.path.expanduser("~/.local/share/DaVinciResolve/Fusion/Scripts/Utility")


# ----------------------------------------------------------------------
# Setup steps (run on a worker thread; `log` is a thread-safe callback)
# ----------------------------------------------------------------------
def _step_pip(log):
    pips = missing_deps()
    if not pips:
        log("Dependencies already installed.")
        return
    _pip_install(pips, log)
    still = missing_deps()
    if still:
        raise RuntimeError(f"Still missing after install: {still}")
    log("Dependencies installed.")


def _pip_install(pips, log):
    log(f"Installing into {LIB_DIR}:")
    log("  " + ", ".join(pips))
    log("(this can take a few minutes)")
    os.makedirs(LIB_DIR, exist_ok=True)
    cmd = [
        sys.executable, "-m", "pip", "install",
        "--upgrade", "--target", LIB_DIR, *pips,
    ]
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )
    for line in proc.stdout:
        line = line.rstrip()
        if line.startswith(("Collecting", "Downloading", "Installing", "Successfully")):
            log("  " + line)
    proc.wait()
    if proc.returncode != 0:
        raise RuntimeError(
            "pip failed. Check your internet connection, then retry."
        )
    importlib.invalidate_caches()


def install_extra_deps(pips, log):
    """Install optional dependency groups (e.g. the NLLB engine) on demand
    into the same private lib dir."""
    _ensure_lib_on_path()
    importlib.invalidate_caches()
    _pip_install(pips, log)


def _step_argos(log):
    import argostranslate.package as apkg

    installed = {(p.from_code, p.to_code) for p in apkg.get_installed_packages()}
    todo = [c for c in ("fr", "es") if ("en", c) not in installed]
    if not todo:
        log("Translation packages already installed (en->fr, en->es).")
        return
    log("Downloading translation packages: " + ", ".join(f"en->{c}" for c in todo))
    apkg.update_package_index()
    available = apkg.get_available_packages()
    for code in todo:
        pkg = next(
            (p for p in available if p.from_code == "en" and p.to_code == code),
            None,
        )
        if pkg is None:
            raise RuntimeError(f"Argos package en->{code} not found in index.")
        log(f"  en->{code}: downloading…")
        apkg.install_from_path(pkg.download())
    log("Translation packages ready.")


def _step_whisper(log):
    from faster_whisper import WhisperModel

    from .config import load_config

    model = load_config().get("whisper_model", "small.en")
    log(f"Caching Whisper model '{model}' (first time only)…")
    WhisperModel(model, device="auto", compute_type="int8")
    log("Whisper model ready.")


def _step_self_install(log, script_path):
    if not script_path or not os.path.isfile(script_path):
        return
    dst_dir = resolve_scripts_dir()
    dst = os.path.join(dst_dir, "LiveTranslate.py")
    try:
        if os.path.abspath(script_path) == os.path.abspath(dst):
            log("Already installed in Resolve's Scripts menu.")
            return
        os.makedirs(dst_dir, exist_ok=True)
        shutil.copy2(script_path, dst)
        log(f"Installed into Resolve: {dst}")
        log("It now appears under Workspace ▸ Scripts ▸ LiveTranslate.")
    except OSError as exc:
        log(f"Note: could not copy into Resolve's Scripts folder ({exc}).")
        log(f"You can copy it manually to: {dst_dir}")


def run_setup_steps(log, script_path=None):
    _ensure_lib_on_path()
    _step_pip(log)
    _step_argos(log)
    _step_whisper(log)
    _step_self_install(log, script_path)
    os.makedirs(LT_HOME, exist_ok=True)
    with open(MARKER, "w", encoding="utf-8") as fh:
        json.dump({"completed": time.strftime("%Y-%m-%d %H:%M:%S")}, fh)
    log("Setup complete.")


# ----------------------------------------------------------------------
# Setup window + launch
# ----------------------------------------------------------------------
def _launch_app(resolve=None):
    _ensure_lib_on_path()
    from .config import load_config
    from .ui import CaptionApp

    CaptionApp(load_config(), resolve=resolve).run()


def ensure_ready(script_path=None, resolve=None):
    """Entry point used by the single-file plugin."""
    if setup_complete():
        # still self-install silently so 'run from Downloads' works forever
        try:
            _step_self_install(lambda _m: None, script_path)
        except Exception:
            pass
        _launch_app(resolve)
        return

    import tkinter as tk

    root = tk.Tk()
    root.title("LiveTranslate — first-run setup")
    root.configure(bg="#101014")
    root.geometry("680x420+160+160")

    tk.Label(
        root,
        text="Setting up LiveTranslate (one time only)",
        fg="#e8e8ee",
        bg="#101014",
        font=("Helvetica", 15, "bold"),
    ).pack(anchor="w", padx=16, pady=(14, 6))

    txt = tk.Text(
        root,
        bg="#16161c",
        fg="#b9b9c3",
        insertbackground="#b9b9c3",
        relief="flat",
        font=("Courier", 11),
        state="disabled",
        wrap="word",
    )
    txt.pack(fill="both", expand=True, padx=16, pady=(0, 12))

    state = {"done": False, "error": None}

    def log(msg):
        def _append():
            txt.configure(state="normal")
            txt.insert("end", msg + "\n")
            txt.see("end")
            txt.configure(state="disabled")

        root.after(0, _append)

    def worker():
        try:
            run_setup_steps(log, script_path=script_path)
            state["done"] = True
        except Exception as exc:
            state["error"] = str(exc)
            log("")
            log("ERROR: " + str(exc))
            if sys.platform.startswith("linux"):
                log(
                    "Linux hint: you may need system packages first:\n"
                    "  sudo apt install python3-tk portaudio19-dev"
                )
            log(traceback.format_exc(limit=3))
            log("Close this window and run LiveTranslate again to retry.")

    threading.Thread(target=worker, daemon=True).start()

    def poll():
        if state["done"]:
            root.destroy()
            _launch_app(resolve)
            return
        if state["error"] is None or root.winfo_exists():
            root.after(200, poll)

    root.after(200, poll)
    root.mainloop()
