"""Integration with the DaVinci Resolve scripting API.

Works both when run from Resolve's Scripts menu (a `resolve` global is
injected) and when run standalone (connects via DaVinciResolveScript).
"""

import os
import sys


def _add_resolve_module_path():
    candidates = []
    if sys.platform == "darwin":
        candidates.append(
            "/Library/Application Support/Blackmagic Design/DaVinci Resolve/Developer/Scripting/Modules"
        )
    elif sys.platform.startswith("win"):
        candidates.append(
            os.path.join(
                os.environ.get("PROGRAMDATA", r"C:\ProgramData"),
                "Blackmagic Design",
                "DaVinci Resolve",
                "Support",
                "Developer",
                "Scripting",
                "Modules",
            )
        )
    else:
        candidates.append("/opt/resolve/Developer/Scripting/Modules")
        candidates.append("/home/resolve/Developer/Scripting/Modules")
    for path in candidates:
        if os.path.isdir(path) and path not in sys.path:
            sys.path.append(path)


def get_resolve(injected=None):
    """Return the Resolve app object, or None if unavailable."""
    if injected is not None:
        return injected
    # When run inside Resolve, the module below is importable and returns
    # the live app. Standalone, it connects to a running Resolve instance
    # (requires 'Local' external scripting in Resolve preferences).
    _add_resolve_module_path()
    try:
        import DaVinciResolveScript as dvr  # type: ignore

        return dvr.scriptapp("Resolve")
    except Exception:
        return None


def import_srt_to_timeline(resolve, srt_path: str) -> tuple[bool, str]:
    """Import an SRT into the current project's media pool and append it
    to the current timeline as a subtitle track."""
    if resolve is None:
        return False, "Not connected to DaVinci Resolve."

    pm = resolve.GetProjectManager()
    project = pm.GetCurrentProject() if pm else None
    if project is None:
        return False, "No project is open in Resolve."

    media_pool = project.GetMediaPool()
    timeline = project.GetCurrentTimeline()
    if timeline is None:
        return False, "No timeline is open — create/open one first."

    items = media_pool.ImportMedia([srt_path])
    if not items:
        return False, f"Resolve could not import {os.path.basename(srt_path)}."

    ok = media_pool.AppendToTimeline(items)
    if not ok:
        return (
            False,
            "Imported to Media Pool, but Resolve refused to append the "
            "subtitle to the timeline. Drag it onto a subtitle track "
            "manually from the Media Pool.",
        )
    return True, f"Added {os.path.basename(srt_path)} to '{timeline.GetName()}'."


def render_timeline_audio(resolve, out_dir: str, status=None) -> tuple:
    """Render the current timeline's audio to a WAV via the Resolve API.

    Returns (path, None) on success or (None, error_message).
    """
    import glob
    import time

    def _status(text):
        if status:
            status(text)

    if resolve is None:
        return None, "Not connected to DaVinci Resolve."
    pm = resolve.GetProjectManager()
    project = pm.GetCurrentProject() if pm else None
    if project is None:
        return None, "No project is open in Resolve."
    timeline = project.GetCurrentTimeline()
    if timeline is None:
        return None, "No timeline is open."

    os.makedirs(out_dir, exist_ok=True)
    name = f"lt-timeline-{int(time.time())}"

    _status("Rendering timeline audio…")
    try:
        # Ask Resolve which render formats/codecs THIS version supports and
        # pick an audio-capable one (names vary across Resolve versions).
        try:
            formats = project.GetRenderFormats() or {}
        except Exception:
            formats = {}
        avail = {str(ext).lower() for ext in formats.values()}
        fmt_set = False
        for ext in ("wav", "aif", "aiff", "mp3", "mov", "mp4"):
            if ext not in avail:
                continue
            try:
                codecs = project.GetRenderCodecs(ext) or {}
            except Exception:
                continue
            # prefer a PCM codec when present
            ordered = sorted(
                codecs.items(),
                key=lambda kv: 0 if any(
                    s in (kv[0] + str(kv[1])).lower()
                    for s in ("pcm", "lpcm", "linear")
                ) else 1,
            )
            for _disp, codec in ordered:
                try:
                    if project.SetCurrentRenderFormatAndCodec(ext, codec):
                        fmt_set = True
                        break
                except Exception:
                    continue
            if fmt_set:
                break
        if not fmt_set:
            return None, (
                "Could not find a supported audio render format. "
                f"Available formats: {sorted(avail)}"
            )
        project.SetRenderSettings(
            {
                "SelectAllFrames": True,
                "ExportVideo": False,
                "ExportAudio": True,
                "TargetDir": out_dir,
                "CustomName": name,
            }
        )
        job_id = project.AddRenderJob()
        if not job_id:
            return None, "Resolve refused the render job."
        project.StartRendering(job_id)
        while project.IsRenderingInProgress():
            time.sleep(0.5)
        job = project.GetRenderJobStatus(job_id) or {}
        project.DeleteRenderJob(job_id)
        if job.get("JobStatus") not in ("Complete", None):
            return None, f"Render failed: {job.get('JobStatus')}"
    except Exception as exc:
        return None, f"Resolve render error: {exc}"

    hits = glob.glob(os.path.join(out_dir, name + "*"))
    if not hits:
        return None, "Render finished but no output file was found."
    return hits[0], None
