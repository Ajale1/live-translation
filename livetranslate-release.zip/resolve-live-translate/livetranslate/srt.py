"""SRT export for recorded caption entries."""

import os
import time


def _ts(seconds: float) -> str:
    ms = int(round(seconds * 1000))
    h, ms = divmod(ms, 3600_000)
    m, ms = divmod(ms, 60_000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def write_srt(entries, lang: str, path: str, source_lang: str = "en") -> str:
    """Write entries to an SRT file. lang == source_lang writes the
    transcription; anything else writes that target's translation."""
    lines = []
    idx = 1
    for e in entries:
        text = e.text if lang == source_lang else e.translations.get(lang, "")
        text = (text or "").strip()
        if not text:
            continue
        lines.append(str(idx))
        lines.append(f"{_ts(e.start)} --> {_ts(e.end)}")
        lines.append(text)
        lines.append("")
        idx += 1
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines))
    return path


def export_session(entries, out_dir: str, source_lang: str = "en",
                   target_langs=("fr", "es")) -> dict:
    """Write one SRT for the source + one per target; returns {lang: path}."""
    os.makedirs(out_dir, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    paths = {}
    for lang in [source_lang] + [t for t in target_langs if t != source_lang]:
        path = os.path.join(out_dir, f"livetranslate-{stamp}.{lang}.srt")
        paths[lang] = write_srt(entries, lang, path, source_lang)
    return paths
