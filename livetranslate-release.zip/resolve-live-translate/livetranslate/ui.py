"""Live caption window (Tkinter — ships with every Python, no Qt needed).

Multilingual layout:
  ┌────────────────────────────────────────────────────────┐
  │  ● Listening…                              [level ▂]   │
  │  Speak in [English ▾]  Translate to [fr ×][ha ×] [+Add]│
  │  EN   source text (dim)                                │
  │  FR   translation (color 1)                            │
  │  HA   translation (color 2)  …one row per target       │
  │  [Start][Stop][Transcribe Timeline][Export][→Timeline] │
  └────────────────────────────────────────────────────────┘
"""

import queue
import tkinter as tk
from tkinter import messagebox

from . import srt as srt_mod
from .config import save_config
from .languages import CODE_TO_NAME, LANGUAGES, TRANSCRIBABLE, name_of
from .pipeline import LivePipeline
from .resolve_bridge import (
    get_resolve,
    import_srt_to_timeline,
    render_timeline_audio,
)

BG = "#101014"
BG2 = "#16161c"
FG_DIM = "#8a8a93"
FG_SRC = "#d8d8de"
ACCENT = "#39d353"
TR_COLORS = ["#7fd4ff", "#ffd479", "#9dff9d", "#ff9de2",
             "#c4a7ff", "#ffb37f", "#7ffff2", "#f2ff7f"]


class SearchDialog(tk.Toplevel):
    """Small searchable language picker: type to filter, Enter/double-click
    to choose. Calls on_pick(code)."""

    def __init__(self, parent, codes, on_pick, title="Choose language"):
        super().__init__(parent)
        self.title(title)
        self.configure(bg=BG2)
        self.geometry("300x340")
        self.transient(parent)
        self.grab_set()
        self.on_pick = on_pick
        self.codes = codes

        self.entry = tk.Entry(self, bg="#1e1e26", fg="#e8e8ee",
                              insertbackground="#e8e8ee", relief="flat")
        self.entry.pack(fill="x", padx=10, pady=10, ipady=4)
        self.entry.bind("<KeyRelease>", lambda e: self._refresh())
        self.entry.bind("<Return>", lambda e: self._choose())
        self.listbox = tk.Listbox(
            self, bg=BG2, fg="#d8d8de", relief="flat",
            selectbackground="#2c2c38", activestyle="none",
        )
        self.listbox.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self.listbox.bind("<Double-Button-1>", lambda e: self._choose())
        self.listbox.bind("<Return>", lambda e: self._choose())
        self._refresh()
        self.entry.focus_set()

    def _refresh(self):
        q = self.entry.get().strip().lower()
        self.listbox.delete(0, "end")
        self._visible = []
        for code in self.codes:
            label = f"{CODE_TO_NAME[code]} ({code})"
            if q in label.lower():
                self.listbox.insert("end", label)
                self._visible.append(code)
        if self._visible:
            self.listbox.selection_set(0)

    def _choose(self):
        sel = self.listbox.curselection()
        idx = sel[0] if sel else 0
        if self._visible:
            self.on_pick(self._visible[idx])
        self.destroy()


class CaptionApp:
    def __init__(self, cfg: dict, resolve=None):
        self.cfg = cfg
        self.resolve = get_resolve(resolve)
        self.ui_q: "queue.Queue" = queue.Queue()
        self.pipeline = None
        self.running = False
        self.last_srt_paths = {}
        self.offline_entries = []
        self.caption_labels = {}  # lang code -> Label

        self.root = tk.Tk()
        self.root.title("LiveTranslate")
        self.root.configure(bg=BG)
        self.root.geometry("940x460+120+120")
        self.root.minsize(680, 340)
        if cfg.get("always_on_top", True):
            self.root.attributes("-topmost", True)
        try:
            self.root.attributes("-alpha", cfg.get("window_opacity", 0.92))
        except tk.TclError:
            pass

        self._build_widgets()
        self._rebuild_language_bar()
        self._rebuild_caption_rows()
        self.root.after(80, self._drain_queue)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    # ------------------------------------------------------------------
    def _build_widgets(self):
        f = self.cfg.get("font_family", "Helvetica")

        top = tk.Frame(self.root, bg=BG)
        top.pack(fill="x", padx=14, pady=(10, 2))
        self.status_dot = tk.Label(top, text="●", fg=FG_DIM, bg=BG, font=(f, 14))
        self.status_dot.pack(side="left")
        self.status_lbl = tk.Label(
            top, text="Idle — press Start", fg=FG_DIM, bg=BG, font=(f, 12)
        )
        self.status_lbl.pack(side="left", padx=(6, 0))
        self.level_bar = tk.Canvas(
            top, width=120, height=10, bg="#1c1c22", highlightthickness=0
        )
        self.level_bar.pack(side="right", pady=4)

        # language bar
        self.lang_bar = tk.Frame(self.root, bg=BG2)
        self.lang_bar.pack(fill="x", padx=14, pady=(6, 4))

        # captions
        self.body = tk.Frame(self.root, bg=BG)
        self.body.pack(fill="both", expand=True, padx=16)

        bar = tk.Frame(self.root, bg=BG)
        bar.pack(fill="x", padx=14, pady=(4, 12))
        self.start_btn = self._btn(bar, "▶ Start", self.start)
        self.stop_btn = self._btn(bar, "■ Stop", self.stop)
        self.timeline_btn = self._btn(bar, "⏲ Transcribe Timeline", self.transcribe_timeline)
        self._btn(bar, "Export SRT", self.export_srt)
        self.push_btn = self._btn(bar, "SRT → Timeline…", self._push_menu)
        self.stop_btn.configure(state="disabled")

    def _btn(self, parent, text, cmd):
        b = tk.Button(
            parent, text=text, command=cmd,
            bg="#1e1e26", fg="#e8e8ee",
            activebackground="#2c2c38", activeforeground="#ffffff",
            relief="flat", padx=12, pady=5,
        )
        b.pack(side="left", padx=(0, 8))
        return b

    # ------------------------------------------------------------------
    # Language selection
    # ------------------------------------------------------------------
    def _rebuild_language_bar(self):
        for w in self.lang_bar.winfo_children():
            w.destroy()
        f = self.cfg.get("font_family", "Helvetica")
        src = self.cfg.get("source_language", "en")

        tk.Label(self.lang_bar, text="Speak in:", fg=FG_DIM, bg=BG2,
                 font=(f, 11)).pack(side="left", padx=(8, 4), pady=6)
        tk.Button(
            self.lang_bar, text=f"{name_of(src)} ▾",
            command=self._pick_source,
            bg="#1e1e26", fg="#e8e8ee", relief="flat", padx=8, pady=2,
        ).pack(side="left", padx=(0, 14))

        tk.Label(self.lang_bar, text="Translate to:", fg=FG_DIM, bg=BG2,
                 font=(f, 11)).pack(side="left", padx=(0, 4))
        for code in self.cfg.get("target_languages", []):
            chip = tk.Button(
                self.lang_bar, text=f"{name_of(code)} ✕",
                command=lambda c=code: self._remove_target(c),
                bg="#24242e", fg="#d8d8de", relief="flat", padx=8, pady=2,
            )
            chip.pack(side="left", padx=2)
        tk.Button(
            self.lang_bar, text="+ Add",
            command=self._add_target,
            bg="#1d3323", fg="#e8e8ee", relief="flat", padx=8, pady=2,
        ).pack(side="left", padx=(6, 8))

    def _pick_source(self):
        codes = [c for c, _, _, ok in LANGUAGES if ok]
        SearchDialog(self.root, codes, self._set_source, "Source language")

    def _set_source(self, code):
        if code not in TRANSCRIBABLE:
            messagebox.showwarning(
                "LiveTranslate",
                f"{name_of(code)} can only be a target language "
                "(no speech recognition available for it).",
            )
            return
        self.cfg["source_language"] = code
        self.cfg["target_languages"] = [
            t for t in self.cfg["target_languages"] if t != code
        ]
        self._languages_changed()

    def _add_target(self):
        codes = [
            c for c, _, _, _ in LANGUAGES
            if c != self.cfg.get("source_language")
            and c not in self.cfg.get("target_languages", [])
        ]
        SearchDialog(self.root, codes, self._append_target, "Add target language")

    def _append_target(self, code):
        self.cfg["target_languages"].append(code)
        self._languages_changed()

    def _remove_target(self, code):
        if len(self.cfg["target_languages"]) <= 1:
            messagebox.showinfo("LiveTranslate", "Keep at least one target language.")
            return
        self.cfg["target_languages"].remove(code)
        self._languages_changed()

    def _languages_changed(self):
        save_config(self.cfg)  # remember for next session
        if self.running:
            self.stop()
            self.status_lbl.configure(
                text="Languages changed — press Start to begin a new session"
            )
        self._rebuild_language_bar()
        self._rebuild_caption_rows()

    # ------------------------------------------------------------------
    # Caption rows
    # ------------------------------------------------------------------
    def _rebuild_caption_rows(self):
        for w in self.body.winfo_children():
            w.destroy()
        self.caption_labels = {}
        f = self.cfg.get("font_family", "Helvetica")
        s_src = self.cfg.get("font_size_source", 20)
        s_tr = self.cfg.get("font_size_translation", 26)
        src = self.cfg.get("source_language", "en")

        def mk_row(code, color, font):
            row = tk.Frame(self.body, bg=BG)
            row.pack(fill="x", pady=3, anchor="w")
            tk.Label(
                row, text=code.upper(), fg=FG_DIM, bg=BG,
                font=("Courier", 11, "bold"), width=4,
            ).pack(side="left", anchor="n", pady=6)
            lbl = tk.Label(
                row, text="", fg=color, bg=BG, font=font,
                justify="left", anchor="w", wraplength=800,
            )
            lbl.pack(side="left", fill="x", expand=True)
            self.caption_labels[code] = lbl

        mk_row(src, FG_SRC, (f, s_src))
        for i, code in enumerate(self.cfg.get("target_languages", [])):
            mk_row(code, TR_COLORS[i % len(TR_COLORS)], (f, s_tr, "bold"))

    # ------------------------------------------------------------------
    # Session control
    # ------------------------------------------------------------------
    def start(self):
        if self.running:
            return
        self.pipeline = LivePipeline(self.cfg, self.ui_q)
        self.start_btn.configure(state="disabled")
        self.status_lbl.configure(text="Loading models…")
        self.root.update_idletasks()
        if self.pipeline.start():
            self.running = True
            self.stop_btn.configure(state="normal")
            self.status_dot.configure(fg=ACCENT)
        else:
            self.start_btn.configure(state="normal")

    def stop(self):
        if not self.running:
            return
        self.pipeline.stop()
        self.running = False
        self.start_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")
        self.status_dot.configure(fg=FG_DIM)

    def export_srt(self):
        entries = (self.pipeline.entries if self.pipeline else []) or self.offline_entries
        if not entries:
            messagebox.showinfo("LiveTranslate", "Nothing recorded yet.")
            return
        self.last_srt_paths = srt_mod.export_session(
            entries,
            self.cfg["srt_dir"],
            self.cfg.get("source_language", "en"),
            self.cfg["target_languages"],
        )
        messagebox.showinfo(
            "LiveTranslate",
            "Exported:\n" + "\n".join(self.last_srt_paths.values()),
        )

    def transcribe_timeline(self):
        """Offline mode: render the timeline's audio via the Resolve API,
        transcribe + translate the whole file with accurate timestamps."""
        if self.running:
            messagebox.showinfo("LiveTranslate", "Stop the live session first.")
            return
        if self.resolve is None:
            messagebox.showwarning(
                "LiveTranslate",
                "Not connected to Resolve. Run this from Workspace ▸ Scripts, "
                "or enable Preferences ▸ System ▸ General ▸ "
                "'External scripting using: Local'.",
            )
            return
        self.timeline_btn.configure(state="disabled")

        import tempfile
        import threading

        def job():
            out_dir = tempfile.mkdtemp(prefix="lt-render-")
            path, err = render_timeline_audio(
                self.resolve,
                out_dir,
                status=lambda t: self.ui_q.put({"kind": "status", "text": t}),
            )
            if err:
                self.ui_q.put({"kind": "error", "text": err})
                self.ui_q.put({"kind": "offline_failed"})
                return
            try:
                from .offline import export, transcribe_file

                def on_progress(done, total, entry):
                    self.ui_q.put(
                        {"kind": "final", "src": entry.text, "tr": entry.translations}
                    )
                    self.ui_q.put(
                        {"kind": "status", "text": f"Translating… {done}/{total}"}
                    )

                entries = transcribe_file(
                    path,
                    self.cfg,
                    progress=on_progress,
                    status=lambda t: self.ui_q.put({"kind": "status", "text": t}),
                )
                if not entries:
                    self.ui_q.put(
                        {"kind": "error", "text": "No speech found in the timeline audio."}
                    )
                    self.ui_q.put({"kind": "offline_failed"})
                    return
                self.offline_entries = entries
                paths = export(entries, self.cfg)
                self.ui_q.put({"kind": "offline_done", "paths": paths})
            except Exception as exc:
                self.ui_q.put(
                    {"kind": "error", "text": f"Offline transcription failed: {exc}"}
                )
                self.ui_q.put({"kind": "offline_failed"})

        threading.Thread(target=job, daemon=True).start()

    # ------------------------------------------------------------------
    # SRT -> timeline
    # ------------------------------------------------------------------
    def _push_menu(self):
        if not self.last_srt_paths:
            self.export_srt()
        if not self.last_srt_paths:
            return
        menu = tk.Menu(self.root, tearoff=0, bg=BG2, fg="#d8d8de")
        for lang, path in self.last_srt_paths.items():
            menu.add_command(
                label=f"{name_of(lang)} ({lang})",
                command=lambda p=path: self._push(p),
            )
        menu.tk_popup(
            self.push_btn.winfo_rootx(),
            self.push_btn.winfo_rooty() + self.push_btn.winfo_height(),
        )

    def _push(self, path):
        ok, msg = import_srt_to_timeline(self.resolve, path)
        (messagebox.showinfo if ok else messagebox.showwarning)("LiveTranslate", msg)

    # ------------------------------------------------------------------
    # Event pump
    # ------------------------------------------------------------------
    def _drain_queue(self):
        src = self.cfg.get("source_language", "en")
        try:
            while True:
                ev = self.ui_q.get_nowait()
                kind = ev["kind"]
                if kind == "status":
                    self.status_lbl.configure(text=ev["text"])
                elif kind == "level":
                    self._draw_level(ev["value"])
                elif kind == "partial":
                    lbl = self.caption_labels.get(src)
                    if lbl:
                        lbl.configure(text=ev["src"] + " …")
                elif kind == "final":
                    lbl = self.caption_labels.get(src)
                    if lbl:
                        lbl.configure(text=ev["src"])
                    for lang, text in (ev.get("tr") or {}).items():
                        lbl = self.caption_labels.get(lang)
                        if lbl:
                            lbl.configure(text=text)
                elif kind == "offline_done":
                    self.last_srt_paths = ev.get("paths", {})
                    self.timeline_btn.configure(state="normal")
                    self.status_dot.configure(fg=ACCENT)
                    self.status_lbl.configure(
                        text="Timeline transcribed — use 'SRT → Timeline…' to insert subtitles"
                    )
                elif kind == "offline_failed":
                    self.timeline_btn.configure(state="normal")
                elif kind == "error":
                    self.status_lbl.configure(text=ev["text"])
                    self.status_dot.configure(fg="#ff5f57")
        except queue.Empty:
            pass
        self.root.after(80, self._drain_queue)

    def _draw_level(self, value: float):
        self.level_bar.delete("all")
        width = min(120, int(value * 2400))
        self.level_bar.create_rectangle(0, 0, width, 10, fill=ACCENT, width=0)

    def _on_close(self):
        if self.running:
            self.stop()
        self.root.destroy()

    def run(self):
        self.root.mainloop()
