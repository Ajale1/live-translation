"""Offline timeline transcription.

Takes a rendered audio file (any format ffmpeg understands — Resolve's WAV
render included), transcribes it with accurate segment timestamps, translates
every segment to the target languages, and returns timed CaptionEntry items
ready for SRT export. Faster than real-time and frame-accurate, but not live.

CLI:  python3 -m livetranslate.offline /path/to/audio.wav
"""

import sys

from . import srt as srt_mod
from .config import load_config
from .pipeline import CaptionEntry
from .transcriber import LocalWhisper
from .translator import make_translator


def transcribe_file(path: str, cfg: dict, progress=None, status=None):
    """Transcribe + translate a whole audio file.

    progress(done, total, entry) is called after each translated segment.
    status(text) is called on phase changes.
    Returns a list of CaptionEntry.
    """
    def _status(text):
        if status:
            status(text)

    _status("Loading models…")
    whisper = LocalWhisper(cfg)          # offline mode always uses the local model
    translator = make_translator(cfg)

    _status("Transcribing audio (faster than real-time)…")
    segments = whisper.transcribe_segments(path)
    if not segments:
        _status("No speech found in the audio.")
        return []

    _status(f"Translating {len(segments)} segments…")
    entries = []
    total = len(segments)
    for i, (start, end, text) in enumerate(segments, 1):
        translations = translator.translate(text)
        entry = CaptionEntry(start, end, text, translations)
        entries.append(entry)
        if progress:
            progress(i, total, entry)
    _status("Done.")
    return entries


def export(entries, cfg: dict) -> dict:
    return srt_mod.export_session(
        entries,
        cfg["srt_dir"],
        cfg.get("source_language", "en"),
        cfg["target_languages"],
    )


def main():
    if len(sys.argv) < 2:
        sys.exit("usage: python3 -m livetranslate.offline <audio-file>")
    cfg = load_config()
    entries = transcribe_file(
        sys.argv[1],
        cfg,
        progress=lambda d, t, e: print(f"[{d}/{t}] {e.text}"),
        status=print,
    )
    if entries:
        paths = export(entries, cfg)
        print("Exported:")
        for lang, p in paths.items():
            print(f"  {lang}: {p}")


if __name__ == "__main__":
    main()
