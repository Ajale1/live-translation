"""Headless backend for the Workflow Integration plugin.

Speaks JSON-lines over stdio:
  stdin  <- {"op": "start"} / {"op": "stop"} / {"op": "export"} /
            {"op": "transcribe_file", "path": ...} /
            {"op": "get_languages"} /
            {"op": "set_languages", "source": "en", "targets": ["fr","ha"]} /
            {"op": "quit"}
  stdout -> pipeline events: {"kind": "status"|"level"|"partial"|"final"|"error", ...}
            plus {"kind": "ready"|"started"|"start_failed"|"stopped"|"exported"|
                  "offline_progress"|"offline_done"|"languages", ...}

Run:  python -m livetranslate.headless
"""

import json
import queue
import sys
import threading

from . import srt as srt_mod
from .config import load_config, save_config
from .languages import ALL_CODES, TRANSCRIBABLE, catalog
from .pipeline import LivePipeline


def emit(obj):
    sys.stdout.write(json.dumps(obj) + "\n")
    sys.stdout.flush()


def main():
    cfg = load_config()
    ui_q: "queue.Queue" = queue.Queue()
    pipeline = {"p": None}
    offline = {"busy": False, "entries": []}
    session = {"entries": []}      # kept after Stop so they stay editable
    translator_cache = {"t": None}

    def current_entries():
        p = pipeline["p"]
        return (p.entries if p else []) or session["entries"] or offline["entries"]

    def get_translator():
        if translator_cache["t"] is None:
            from .translator import make_translator

            translator_cache["t"] = make_translator(
                cfg, log=lambda t: ui_q.put({"kind": "status", "text": t})
            )
        return translator_cache["t"]

    def entry_dict(i, e):
        return {"index": i, "start": e.start, "end": e.end,
                "src": e.text, "tr": e.translations}

    def drain():
        while True:
            ev = ui_q.get()
            if ev is None:
                return
            emit(ev)

    threading.Thread(target=drain, daemon=True).start()

    def emit_languages():
        emit(
            {
                "kind": "languages",
                "catalog": catalog(),
                "source": cfg.get("source_language", "en"),
                "targets": cfg.get("target_languages", ["fr", "es"]),
            }
        )

    emit({"kind": "ready"})
    emit_languages()

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            cmd = json.loads(line)
        except ValueError:
            continue
        op = cmd.get("op")

        if op == "start":
            if pipeline["p"] is not None:
                continue
            session["entries"] = []
            p = LivePipeline(cfg, ui_q)
            if p.start():
                pipeline["p"] = p
                emit({"kind": "started"})
            else:
                emit({"kind": "start_failed"})

        elif op == "stop":
            p = pipeline["p"]
            if p is not None:
                p.stop()
                session["entries"] = p.entries   # keep for editing/export
                pipeline["p"] = None
                emit({"kind": "stopped"})

        elif op == "get_languages":
            emit_languages()

        elif op == "set_languages":
            source = cmd.get("source", cfg.get("source_language", "en"))
            targets = [t for t in cmd.get("targets", []) if t in ALL_CODES]
            if source not in ALL_CODES:
                emit({"kind": "error", "text": f"Unknown language: {source}"})
                continue
            if source not in TRANSCRIBABLE:
                emit({"kind": "error",
                      "text": f"'{source}' can only be a target language "
                              "(no speech recognition available for it)."})
                continue
            targets = [t for t in targets if t != source]
            if not targets:
                emit({"kind": "error", "text": "Pick at least one target language."})
                continue
            # a language change applies to the NEXT session
            p = pipeline["p"]
            if p is not None:
                p.stop()
                pipeline["p"] = None
                emit({"kind": "stopped"})
            cfg["source_language"] = source
            cfg["target_languages"] = targets
            save_config(cfg)
            translator_cache["t"] = None   # rebuild for the new languages
            emit_languages()
            emit({"kind": "status", "text": "Languages saved — press Start"})

        elif op == "get_entries":
            emit({
                "kind": "entries",
                "entries": [entry_dict(i, e) for i, e in enumerate(current_entries())],
            })

        elif op == "update_entry":
            # Edit a segment's source text and/or translations from the UI.
            # {"op":"update_entry","index":N,"src":"...","tr":{"fr":"..."},
            #  "retranslate":true}
            entries = current_entries()
            idx = cmd.get("index", -1)
            if not isinstance(idx, int) or not (0 <= idx < len(entries)):
                emit({"kind": "error", "text": f"No such segment: {idx}"})
                continue
            entry = entries[idx]
            new_src = cmd.get("src")
            if isinstance(new_src, str) and new_src.strip():
                entry.text = new_src.strip()
            manual_tr = cmd.get("tr")
            if isinstance(manual_tr, dict):
                for lang, text in manual_tr.items():
                    if isinstance(text, str):
                        entry.translations[lang] = text.strip()

            if cmd.get("retranslate"):
                def retranslate_job(e=entry, i=idx):
                    try:
                        e.translations = get_translator().translate(e.text)
                        ui_q.put({"kind": "entry_updated", **entry_dict(i, e)})
                        ui_q.put({"kind": "status",
                                  "text": f"Segment {i + 1} re-translated."})
                    except Exception as exc:
                        ui_q.put({"kind": "error",
                                  "text": f"Re-translate failed: {exc}"})

                threading.Thread(target=retranslate_job, daemon=True).start()
            else:
                emit({"kind": "entry_updated", **entry_dict(idx, entry)})

        elif op == "export":
            entries = current_entries()
            if not entries:
                emit({"kind": "error", "text": "Nothing recorded yet."})
                continue
            paths = srt_mod.export_session(
                entries,
                cfg["srt_dir"],
                cfg.get("source_language", "en"),
                cfg["target_languages"],
            )
            emit({"kind": "exported", "paths": paths})

        elif op == "transcribe_file":
            # offline mode: whole audio file -> timed, translated captions
            path = cmd.get("path", "")
            if offline["busy"]:
                emit({"kind": "error", "text": "A transcription is already running."})
                continue

            def offline_job(p=path):
                try:
                    from .offline import export, transcribe_file

                    def on_progress(done, total, entry):
                        ui_q.put({"kind": "final", "src": entry.text, "tr": entry.translations})
                        ui_q.put({"kind": "offline_progress", "done": done, "total": total})

                    entries = transcribe_file(
                        p,
                        cfg,
                        progress=on_progress,
                        status=lambda t: ui_q.put({"kind": "status", "text": t}),
                    )
                    if entries:
                        paths = export(entries, cfg)
                        offline["entries"] = entries
                        ui_q.put({"kind": "offline_done", "paths": paths})
                    else:
                        ui_q.put({"kind": "error", "text": "No speech found in the timeline audio."})
                except Exception as exc:
                    ui_q.put({"kind": "error", "text": f"Offline transcription failed: {exc}"})
                finally:
                    offline["busy"] = False

            offline["busy"] = True
            threading.Thread(target=offline_job, daemon=True).start()

        elif op == "quit":
            break

    p = pipeline["p"]
    if p is not None:
        p.stop()
    ui_q.put(None)


if __name__ == "__main__":
    main()
