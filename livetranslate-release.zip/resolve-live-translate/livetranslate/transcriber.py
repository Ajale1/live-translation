"""Speech-to-text engines.

LocalWhisper  -- faster-whisper running on this machine (default, offline).
OpenAIWhisper -- OpenAI's hosted Whisper API (needs OPENAI_API_KEY).
"""

import io
import os
import wave

import numpy as np


class TranscriberError(RuntimeError):
    pass


class LocalWhisper:
    def __init__(self, cfg: dict):
        try:
            from faster_whisper import WhisperModel
        except ImportError as exc:
            raise TranscriberError(
                "faster-whisper is not installed. Run the LiveTranslate "
                "installer (install.py) with Resolve's Python."
            ) from exc

        from .languages import TRANSCRIBABLE, name_of

        self.language = cfg.get("source_language", "en")
        if self.language not in TRANSCRIBABLE:
            raise TranscriberError(
                f"Speech recognition for {name_of(self.language)} is not "
                "supported — it can only be used as a translation target. "
                "Pick a different source language."
            )

        name = cfg.get("whisper_model", "small.en")
        # .en models are English-only; switch to the multilingual variant
        # automatically for any other source language.
        if self.language != "en" and name.endswith(".en"):
            name = name[: -len(".en")]

        compute = cfg.get("whisper_compute", "auto")
        if compute == "auto":
            compute = "int8"
        self.model = WhisperModel(
            name,
            device="auto",
            compute_type=compute,
        )
        self.sample_rate = cfg["sample_rate"]

    def transcribe(self, audio: np.ndarray) -> str:
        segments, _info = self.model.transcribe(
            audio,
            language=self.language,
            beam_size=1,
            vad_filter=True,
            condition_on_previous_text=False,
        )
        return " ".join(seg.text.strip() for seg in segments).strip()

    def transcribe_segments(self, source):
        """Transcribe a whole audio file (path) or array with timestamps.

        Returns [(start_s, end_s, text), ...]. Used by the offline
        timeline-transcription mode; beam_size=5 for best accuracy since
        this doesn't need to keep up with live speech.
        """
        segments, _info = self.model.transcribe(
            source,
            language=self.language,
            beam_size=5,
            vad_filter=True,
        )
        return [
            (seg.start, seg.end, seg.text.strip())
            for seg in segments
            if seg.text.strip()
        ]


class OpenAIWhisper:
    def __init__(self, cfg: dict):
        try:
            from openai import OpenAI
        except ImportError as exc:
            raise TranscriberError(
                "The 'openai' package is not installed."
            ) from exc
        if not os.environ.get("OPENAI_API_KEY"):
            raise TranscriberError(
                "OPENAI_API_KEY is not set; cannot use the OpenAI engine."
            )
        self.client = OpenAI()
        self.model = cfg.get("openai_model", "whisper-1")
        self.sample_rate = cfg["sample_rate"]
        self.language = cfg.get("source_language", "en")

    def transcribe(self, audio: np.ndarray) -> str:
        buf = io.BytesIO()
        pcm = (np.clip(audio, -1.0, 1.0) * 32767).astype(np.int16)
        with wave.open(buf, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(self.sample_rate)
            wf.writeframes(pcm.tobytes())
        buf.seek(0)
        buf.name = "chunk.wav"
        resp = self.client.audio.transcriptions.create(
            model=self.model, file=buf, language=self.language
        )
        return (resp.text or "").strip()


def make_transcriber(cfg: dict):
    if cfg.get("engine", "local") == "openai":
        return OpenAIWhisper(cfg)
    return LocalWhisper(cfg)
