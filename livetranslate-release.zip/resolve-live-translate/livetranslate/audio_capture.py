"""Microphone capture with a simple energy-based VAD segmenter.

Produces two kinds of events on the output queue:
  ("partial", np.ndarray)  -- audio so far in the currently open segment
  ("final",   np.ndarray)  -- a completed speech segment
"""

import queue
import threading
import time

import numpy as np
import sounddevice as sd


class MicSegmenter:
    def __init__(self, cfg: dict, out_queue: "queue.Queue"):
        self.cfg = cfg
        self.out = out_queue
        self.sample_rate = cfg["sample_rate"]
        self.block = int(self.sample_rate * cfg["block_ms"] / 1000)
        self.silence_blocks_end = max(
            1, int(cfg["silence_end_ms"] / cfg["block_ms"])
        )
        self.max_segment_samples = int(cfg["max_segment_s"] * self.sample_rate)
        self.partial_interval = cfg["partial_interval_s"]

        self._stop = threading.Event()
        self._thread = None
        self._level = 0.0  # last RMS, for the UI level meter

    # ------------------------------------------------------------------
    @property
    def level(self) -> float:
        return self._level

    def start(self):
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=3)

    # ------------------------------------------------------------------
    def _run(self):
        threshold = self.cfg["vad_energy_threshold"]
        raw_q: "queue.Queue" = queue.Queue()

        def callback(indata, frames, t, status):  # noqa: ANN001
            raw_q.put(indata[:, 0].copy())

        stream = sd.InputStream(
            samplerate=self.sample_rate,
            blocksize=self.block,
            channels=1,
            dtype="float32",
            device=self.cfg.get("input_device"),
            callback=callback,
        )

        segment = []
        silence_run = 0
        in_speech = False
        last_partial = 0.0

        with stream:
            while not self._stop.is_set():
                try:
                    chunk = raw_q.get(timeout=0.25)
                except queue.Empty:
                    continue

                rms = float(np.sqrt(np.mean(chunk**2)))
                self._level = rms
                voiced = rms >= threshold

                if voiced:
                    if not in_speech:
                        in_speech = True
                        segment = []
                    silence_run = 0
                    segment.append(chunk)
                elif in_speech:
                    silence_run += 1
                    segment.append(chunk)

                if not in_speech:
                    continue

                total = sum(len(c) for c in segment)
                segment_done = (
                    silence_run >= self.silence_blocks_end
                    or total >= self.max_segment_samples
                )

                if segment_done:
                    audio = np.concatenate(segment)
                    if self._has_speech(audio, threshold):
                        self.out.put(("final", audio))
                    segment = []
                    in_speech = False
                    silence_run = 0
                    last_partial = 0.0
                else:
                    now = time.monotonic()
                    if now - last_partial >= self.partial_interval:
                        last_partial = now
                        audio = np.concatenate(segment)
                        if len(audio) >= self.sample_rate // 2:
                            self.out.put(("partial", audio))

        # flush whatever is left when stopping
        if segment:
            audio = np.concatenate(segment)
            if self._has_speech(audio, threshold):
                self.out.put(("final", audio))

    @staticmethod
    def _has_speech(audio: np.ndarray, threshold: float) -> bool:
        return float(np.sqrt(np.mean(audio**2))) >= threshold * 0.5


def list_input_devices():
    """Return [(index, name), ...] of available input devices."""
    devices = []
    for idx, dev in enumerate(sd.query_devices()):
        if dev.get("max_input_channels", 0) > 0:
            devices.append((idx, dev["name"]))
    return devices
