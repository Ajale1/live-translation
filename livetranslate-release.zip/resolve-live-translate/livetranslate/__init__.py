"""LiveTranslate for DaVinci Resolve.

Real-time microphone transcription (English) with instant translation to
French and Spanish, shown in a live caption window and insertable into the
Resolve timeline as subtitles.
"""

__version__ = "1.3.1"
