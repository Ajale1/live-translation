@echo off
REM LiveTranslate - double-click installer for DaVinci Resolve STUDIO (Windows).
REM If Windows SmartScreen warns: click "More info" then "Run anyway".
title LiveTranslate installer (Resolve Studio)
cd /d "%~dp0"
echo ===================================================
echo   LiveTranslate installer (Resolve Studio, Windows)
echo ===================================================
echo.

where python >nul 2>nul
if errorlevel 1 (
  where py >nul 2>nul
  if errorlevel 1 (
    echo Python is not installed.
    echo Get it from https://www.python.org/downloads/
    echo IMPORTANT: tick "Add Python to PATH" during install, then run this again.
    pause
    exit /b 1
  )
)

where npm >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed - needed for the plugin panel.
  echo Get the LTS version from https://nodejs.org then run this again.
  pause
  exit /b 1
)

echo NOTE: if this fails with "permission denied", close this window,
echo right-click this file and choose "Run as administrator".
echo.

where python >nul 2>nul
if errorlevel 1 (
  py install-plugin.py
) else (
  python install-plugin.py
)

echo.
if errorlevel 1 (
  echo Something went wrong above. Take a screenshot of this window
  echo and open an issue on the GitHub page.
) else (
  echo ===================================================
  echo   DONE! Restart DaVinci Resolve, then open:
  echo   Workspace ^> Workflow Integrations ^> LiveTranslate
  echo ===================================================
)
pause
