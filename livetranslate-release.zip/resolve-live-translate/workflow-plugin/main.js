// LiveTranslate — DaVinci Resolve Workflow Integration plugin (Electron main).
//
// Responsibilities:
//   * register with Resolve via WorkflowIntegration.node
//   * open the caption panel window (renderer/)
//   * spawn the Python backend (livetranslate.headless) and bridge its
//     JSON-lines events to the renderer over IPC
//   * push exported SRT files into the current timeline via the Resolve API

const { app, BrowserWindow, ipcMain } = require('electron');
const { spawn } = require('child_process');
const path = require('path');
const os = require('os');
const fs = require('fs');

const PLUGIN_ID = 'com.livetranslate.resolve';
const LIB_DIR = path.join(os.homedir(), '.livetranslate', 'lib');

// ---------------------------------------------------------------------------
// Resolve API (WorkflowIntegration.node is copied here by install-plugin.py)
// ---------------------------------------------------------------------------
let wi = null;
try {
  wi = require('./WorkflowIntegration.node');
} catch (err) {
  console.warn('WorkflowIntegration.node not found — timeline push disabled.', err.message);
}

function getResolve() {
  if (!wi) return null;
  try {
    return wi.GetResolve();
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// Python backend
// ---------------------------------------------------------------------------
let backend = null;
let win = null;

function pythonCandidates() {
  const fromEnv = process.env.LIVETRANSLATE_PYTHON;
  const list = [];
  if (fromEnv) list.push(fromEnv);
  if (process.platform === 'win32') list.push('python', 'py');
  else list.push('python3', 'python');
  return list;
}

function startBackend() {
  if (backend) return;
  const env = Object.assign({}, process.env, {
    PYTHONPATH: [__dirname, LIB_DIR, process.env.PYTHONPATH || ''].join(path.delimiter),
    PYTHONUNBUFFERED: '1',
  });

  const candidates = pythonCandidates();
  let spawned = null;
  for (const py of candidates) {
    try {
      spawned = spawn(py, ['-m', 'livetranslate.headless'], { env, cwd: __dirname });
      break;
    } catch {
      /* try next */
    }
  }
  if (!spawned) {
    send({ kind: 'error', text: 'Python 3 not found. Install Python 3.9+ and restart.' });
    return;
  }
  backend = spawned;

  let buf = '';
  backend.stdout.on('data', (chunk) => {
    buf += chunk.toString();
    let idx;
    while ((idx = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, idx).trim();
      buf = buf.slice(idx + 1);
      if (!line) continue;
      try {
        send(JSON.parse(line));
      } catch {
        /* non-JSON noise from libs — ignore */
      }
    }
  });
  backend.stderr.on('data', (d) => console.error('[backend]', d.toString()));
  backend.on('exit', (code) => {
    backend = null;
    send({ kind: 'error', text: `Backend exited (code ${code}). Run the LiveTranslate setup once: python3 LiveTranslate.py` });
  });
}

function backendCmd(obj) {
  if (!backend) startBackend();
  if (backend && backend.stdin.writable) {
    backend.stdin.write(JSON.stringify(obj) + '\n');
  }
}

function send(obj) {
  if (win && !win.isDestroyed()) win.webContents.send('lt-event', obj);
}

// ---------------------------------------------------------------------------
// IPC from the renderer
// ---------------------------------------------------------------------------
ipcMain.on('lt-command', (_e, cmd) => backendCmd(cmd));

ipcMain.handle('lt-transcribe-timeline', async () => {
  const resolve = getResolve();
  if (!resolve) return { ok: false, msg: 'Not connected to Resolve.' };
  try {
    const pm = resolve.GetProjectManager();
    const project = pm && pm.GetCurrentProject();
    if (!project) return { ok: false, msg: 'No project is open.' };
    const timeline = project.GetCurrentTimeline();
    if (!timeline) return { ok: false, msg: 'No timeline is open.' };

    const outDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lt-render-'));
    const name = `lt-timeline-${Date.now()}`;

    send({ kind: 'status', text: 'Rendering timeline audio\u2026' });
    // Ask Resolve which render formats/codecs THIS version supports and
    // pick an audio-capable one (names vary across Resolve versions).
    const wantedExts = ['wav', 'aif', 'aiff', 'mp3', 'mov', 'mp4'];
    let fmtSet = false;
    let fmtErr = '';
    let formats = {};
    try { formats = project.GetRenderFormats() || {}; } catch { /* ignore */ }
    const availExts = Object.values(formats).map((e) => String(e).toLowerCase());
    for (const ext of wantedExts) {
      if (!availExts.includes(ext)) continue;
      let codecs = {};
      try { codecs = project.GetRenderCodecs(ext) || {}; } catch { continue; }
      const entries = Object.entries(codecs); // [displayName, codecValue]
      if (entries.length === 0) continue;
      // prefer a PCM codec when present
      entries.sort(([a], [b]) => {
        const isPcm = (s) => /pcm|lpcm|linear/i.test(s) ? 0 : 1;
        return isPcm(a) - isPcm(b);
      });
      for (const [, codecValue] of entries) {
        try {
          if (project.SetCurrentRenderFormatAndCodec(ext, codecValue)) {
            fmtSet = true;
            break;
          }
        } catch (e) { fmtErr = e.message; }
      }
      if (fmtSet) break;
    }
    if (!fmtSet) {
      return { ok: false, msg: `Could not find a supported audio render format (${fmtErr || 'none accepted'}). Available: ${availExts.join(', ')}` };
    }
    project.SetRenderSettings({
      SelectAllFrames: true,
      ExportVideo: false,
      ExportAudio: true,
      TargetDir: outDir,
      CustomName: name,
    });
    const jobId = project.AddRenderJob();
    if (!jobId) return { ok: false, msg: 'Resolve refused the render job.' };
    project.StartRendering(jobId);
    while (project.IsRenderingInProgress()) {
      await new Promise((r) => setTimeout(r, 500));
    }
    const status = project.GetRenderJobStatus(jobId) || {};
    project.DeleteRenderJob(jobId);
    if (status.JobStatus && status.JobStatus !== 'Complete') {
      return { ok: false, msg: `Render failed: ${status.JobStatus}` };
    }
    const hit = fs.readdirSync(outDir).find((f) => f.startsWith(name));
    if (!hit) return { ok: false, msg: 'Render finished but no audio file found.' };

    backendCmd({ op: 'transcribe_file', path: path.join(outDir, hit) });
    return { ok: true, msg: 'Timeline audio rendered — transcribing\u2026' };
  } catch (err) {
    return { ok: false, msg: `Resolve API error: ${err.message}` };
  }
});

ipcMain.handle('lt-push-srt', async (_e, srtPath) => {
  const resolve = getResolve();
  if (!resolve) return { ok: false, msg: 'Not connected to Resolve (Studio + Workflow Integrations required).' };
  if (!fs.existsSync(srtPath)) return { ok: false, msg: `File not found: ${srtPath}` };
  try {
    const pm = resolve.GetProjectManager();
    const project = pm && pm.GetCurrentProject();
    if (!project) return { ok: false, msg: 'No project is open.' };
    const timeline = project.GetCurrentTimeline();
    if (!timeline) return { ok: false, msg: 'No timeline is open.' };
    const mediaPool = project.GetMediaPool();
    const items = mediaPool.ImportMedia([srtPath]);
    if (!items || items.length === 0) return { ok: false, msg: 'Resolve could not import the SRT.' };
    const ok = mediaPool.AppendToTimeline(items);
    if (!ok) return { ok: false, msg: 'Imported to Media Pool; drag it to a subtitle track manually.' };
    return { ok: true, msg: `Added ${path.basename(srtPath)} to "${timeline.GetName()}".` };
  } catch (err) {
    return { ok: false, msg: `Resolve API error: ${err.message}` };
  }
});

// ---------------------------------------------------------------------------
// Window / lifecycle
// ---------------------------------------------------------------------------
function createWindow() {
  win = new BrowserWindow({
    width: 920,
    height: 420,
    minWidth: 640,
    minHeight: 320,
    alwaysOnTop: true,
    backgroundColor: '#101014',
    title: 'LiveTranslate — EN \u2192 FR / ES',
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    },
  });
  win.setMenuBarVisibility(false);
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.on('closed', () => {
    win = null;
  });
}

app.whenReady().then(() => {
  if (wi) {
    try {
      wi.Initialize(PLUGIN_ID);
    } catch (err) {
      console.warn('WorkflowIntegration Initialize failed:', err.message);
    }
  }
  createWindow();
  startBackend();
});

app.on('window-all-closed', () => {
  if (backend) {
    try {
      backendCmd({ op: 'quit' });
      backend.kill();
    } catch { /* already gone */ }
  }
  if (wi) {
    try { wi.CleanUp(); } catch { /* ignore */ }
  }
  app.quit();
});
