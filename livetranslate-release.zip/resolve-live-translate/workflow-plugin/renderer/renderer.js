// LiveTranslate panel logic (Electron renderer) — multilingual version.
const { ipcRenderer } = require('electron');

const $ = (id) => document.getElementById(id);
const dot = $('dot'), status = $('status'), meterFill = $('meterFill');
const captions = $('captions'), chips = $('chips'), pushButtons = $('pushButtons');
const editor = $('editor');
const srcInput = $('srcInput'), tgtInput = $('tgtInput');
const srcList = $('srcList'), tgtList = $('tgtList');
const btnStart = $('start'), btnStop = $('stop'), btnExport = $('export');
const btnTimeline = $('timeline'), btnApply = $('applyLang'), btnEdit = $('edit');

const COLORS = ['#7fd4ff', '#ffd479', '#9dff9d', '#ff9de2', '#c4a7ff', '#ffb37f', '#7ffff2', '#f2ff7f'];

let catalog = [];          // [{code, name, transcribable}]
let source = 'en';
let targets = ['fr', 'es'];
let srtPaths = {};
let running = false;
let rowEls = {};           // lang code -> caption div

const nameOf = (c) => (catalog.find((l) => l.code === c) || { name: c }).name;
const codeOf = (typed) => {
  const t = typed.trim().toLowerCase();
  const hit = catalog.find(
    (l) => l.name.toLowerCase() === t || l.code === t ||
           `${l.name.toLowerCase()} (${l.code})` === t
  );
  return hit ? hit.code : null;
};

function setStatus(text, cls) { status.textContent = text; dot.className = cls || ''; }
function cmd(obj) { ipcRenderer.send('lt-command', obj); }

// ---------------------------------------------------------------------------
// Language bar
// ---------------------------------------------------------------------------
function fillDatalists() {
  srcList.innerHTML = catalog
    .filter((l) => l.transcribable)
    .map((l) => `<option value="${l.name} (${l.code})">`) .join('');
  tgtList.innerHTML = catalog
    .map((l) => `<option value="${l.name} (${l.code})">`).join('');
}

function renderChips() {
  chips.innerHTML = '';
  targets.forEach((t) => {
    const chip = document.createElement('span');
    chip.className = 'chip';
    chip.innerHTML = `${nameOf(t)} <b title="remove">\u00d7</b>`;
    chip.querySelector('b').onclick = () => {
      targets = targets.filter((x) => x !== t);
      renderChips();
    };
    chips.appendChild(chip);
  });
}

tgtInput.addEventListener('change', () => {
  const code = codeOf(tgtInput.value);
  tgtInput.value = '';
  if (!code) return;
  if (code === source) { setStatus('That is the source language.', 'err'); return; }
  if (!targets.includes(code)) { targets.push(code); renderChips(); }
});

btnApply.onclick = () => {
  const srcCode = codeOf(srcInput.value) || source;
  cmd({ op: 'set_languages', source: srcCode, targets });
};

// ---------------------------------------------------------------------------
// Caption rows (one per language, rebuilt when languages change)
// ---------------------------------------------------------------------------
function rebuildRows() {
  captions.innerHTML = '';
  rowEls = {};
  const mkRow = (code, cls, color) => {
    const row = document.createElement('div');
    row.className = 'row';
    const tag = document.createElement('span');
    tag.className = 'tag';
    tag.textContent = code.toUpperCase();
    const cap = document.createElement('div');
    cap.className = `cap ${cls}`;
    if (color) cap.style.color = color;
    row.appendChild(tag);
    row.appendChild(cap);
    captions.appendChild(row);
    rowEls[code] = cap;
  };
  mkRow(source, 'src', null);
  targets.forEach((t, i) => mkRow(t, 'tr', COLORS[i % COLORS.length]));
}

function rebuildPushButtons() {
  pushButtons.innerHTML = '';
  Object.keys(srtPaths).forEach((lang) => {
    const b = document.createElement('button');
    b.textContent = `SRT \u2192 Timeline (${lang.toUpperCase()})`;
    b.onclick = async () => {
      const res = await ipcRenderer.invoke('lt-push-srt', srtPaths[lang]);
      setStatus(res.msg, res.ok ? (running ? 'live' : '') : 'err');
    };
    pushButtons.appendChild(b);
  });
}

// ---------------------------------------------------------------------------
// Controls
// ---------------------------------------------------------------------------
btnStart.onclick = () => {
  setStatus('Loading models\u2026');
  btnStart.disabled = true;
  cmd({ op: 'start' });
};
btnStop.onclick = () => cmd({ op: 'stop' });
btnExport.onclick = () => cmd({ op: 'export' });

btnTimeline.onclick = async () => {
  btnTimeline.disabled = true;
  setStatus('Rendering timeline audio\u2026');
  const res = await ipcRenderer.invoke('lt-transcribe-timeline');
  if (!res.ok) { setStatus(res.msg, 'err'); btnTimeline.disabled = false; }
  else setStatus(res.msg);
};

// ---------------------------------------------------------------------------
// Review / Edit view
// ---------------------------------------------------------------------------
let editing = false;

function fmtTime(s) {
  const m = Math.floor(s / 60), sec = (s % 60).toFixed(1);
  return `${m}:${String(sec).padStart(4, '0')}`;
}

btnEdit.onclick = () => {
  editing = !editing;
  if (editing) {
    btnEdit.textContent = '\u2713 Done editing';
    captions.style.display = 'none';
    editor.style.display = 'flex';
    editor.innerHTML = '<div style="color:#8a8a93;font-size:13px;">Loading transcript\u2026</div>';
    cmd({ op: 'get_entries' });
  } else {
    btnEdit.textContent = '\u270E Review / Edit';
    editor.style.display = 'none';
    captions.style.display = 'flex';
    srtPaths = {};            // stale after edits — force re-export
    pushButtons.innerHTML = '';
    setStatus('Edits saved \u2014 press Export SRT to write the corrected files');
  }
};

function buildEditor(entries) {
  editor.innerHTML = '';
  if (!entries.length) {
    editor.innerHTML = '<div style="color:#8a8a93;font-size:13px;">Nothing recorded yet.</div>';
    return;
  }
  entries.forEach((e) => {
    const seg = document.createElement('div');
    seg.className = 'seg';
    seg.dataset.index = e.index;

    const head = document.createElement('div');
    head.className = 'time';
    head.innerHTML = `<span>#${e.index + 1} \u00b7 ${fmtTime(e.start)} \u2192 ${fmtTime(e.end)}</span>`;
    const retr = document.createElement('button');
    retr.className = 'retr';
    retr.textContent = '\u21bb Re-translate';
    head.appendChild(retr);
    seg.appendChild(head);

    const srcTa = document.createElement('textarea');
    srcTa.value = e.src;
    srcTa.dataset.lang = '__src__';
    seg.appendChild(srcTa);

    const taByLang = {};
    Object.entries(e.tr || {}).forEach(([lang, text]) => {
      const lab = document.createElement('div');
      lab.className = 'langlabel';
      lab.textContent = lang.toUpperCase();
      seg.appendChild(lab);
      const ta = document.createElement('textarea');
      ta.value = text || '';
      ta.dataset.lang = lang;
      seg.appendChild(ta);
      taByLang[lang] = ta;
    });
    seg._taByLang = taByLang;
    seg._srcTa = srcTa;

    // save a field when the user leaves it
    seg.querySelectorAll('textarea').forEach((ta) => {
      ta.addEventListener('input', () => ta.classList.add('dirty'));
      ta.addEventListener('blur', () => {
        if (!ta.classList.contains('dirty')) return;
        ta.classList.remove('dirty');
        const payload = { op: 'update_entry', index: e.index };
        if (ta.dataset.lang === '__src__') payload.src = ta.value;
        else payload.tr = { [ta.dataset.lang]: ta.value };
        cmd(payload);
      });
    });

    // re-translate all targets from the (possibly corrected) source
    retr.onclick = () => {
      retr.textContent = '\u21bb working\u2026';
      retr.disabled = true;
      cmd({
        op: 'update_entry',
        index: e.index,
        src: srcTa.value,
        retranslate: true,
      });
    };

    editor.appendChild(seg);
  });
}

function applyEntryUpdate(ev) {
  const seg = editor.querySelector(`.seg[data-index="${ev.index}"]`);
  if (!seg) return;
  seg._srcTa.value = ev.src;
  Object.entries(ev.tr || {}).forEach(([lang, text]) => {
    if (seg._taByLang[lang]) seg._taByLang[lang].value = text || '';
  });
  const retr = seg.querySelector('.retr');
  retr.textContent = '\u21bb Re-translate';
  retr.disabled = false;
}

// ---------------------------------------------------------------------------
// Backend events
// ---------------------------------------------------------------------------
ipcRenderer.on('lt-event', (_e, ev) => {
  switch (ev.kind) {
    case 'ready':
      setStatus('Ready \u2014 press Start');
      break;
    case 'languages':
      catalog = ev.catalog || catalog;
      source = ev.source;
      targets = [...ev.targets];
      fillDatalists();
      srcInput.value = `${nameOf(source)} (${source})`;
      renderChips();
      rebuildRows();
      break;
    case 'started':
      running = true;
      btnStop.disabled = false;
      setStatus(`Listening \u2014 speak in ${nameOf(source)}`, 'live');
      break;
    case 'start_failed':
      btnStart.disabled = false;
      setStatus('Could not start \u2014 see error / run setup once', 'err');
      break;
    case 'stopped':
      running = false;
      btnStart.disabled = false;
      btnStop.disabled = true;
      btnEdit.disabled = false;
      setStatus('Stopped \u2014 Review / Edit, then Export SRT');
      break;
    case 'entries':
      buildEditor(ev.entries || []);
      break;
    case 'entry_updated':
      applyEntryUpdate(ev);
      break;
    case 'status':
      setStatus(ev.text, running ? 'live' : '');
      break;
    case 'level':
      meterFill.style.width = Math.min(120, ev.value * 2400) + 'px';
      break;
    case 'partial':
      if (rowEls[source]) rowEls[source].textContent = ev.src + ' \u2026';
      break;
    case 'final':
      if (rowEls[source]) rowEls[source].textContent = ev.src;
      Object.entries(ev.tr || {}).forEach(([lang, text]) => {
        if (rowEls[lang]) rowEls[lang].textContent = text;
      });
      break;
    case 'offline_progress':
      setStatus(`Translating\u2026 ${ev.done}/${ev.total}`);
      break;
    case 'offline_done':
      srtPaths = ev.paths || {};
      rebuildPushButtons();
      btnTimeline.disabled = false;
      btnEdit.disabled = false;
      setStatus('Timeline transcribed \u2014 Review / Edit or push the SRTs', 'live');
      break;
    case 'exported':
      srtPaths = ev.paths || {};
      rebuildPushButtons();
      setStatus('Exported: ' + Object.values(srtPaths).join('  '), running ? 'live' : '');
      break;
    case 'error':
      setStatus(ev.text, 'err');
      btnStart.disabled = false;
      btnTimeline.disabled = false;
      break;
  }
});
