# Attributions & Model Licenses

LiveTranslate's own source code is MIT-licensed (see LICENSE). At install
time and at runtime it downloads and uses the following third-party
software and AI models, which remain under their own licenses:

## AI models

| Model | Publisher | License | Used for |
|---|---|---|---|
| [Whisper](https://github.com/openai/whisper) (via faster-whisper) | OpenAI | MIT | Speech recognition (all source languages) |
| [NLLB-200 distilled 600M](https://huggingface.co/facebook/nllb-200-distilled-600M) | Meta AI | **CC-BY-NC-4.0 (non-commercial)** | Translation for languages Argos doesn't cover (incl. Hausa, Yoruba, Igbo, Swahili, Amharic, Somali, Shona, Lingala, Malagasy) |
| [Argos Translate models](https://github.com/argosopentech/argos-translate) | Argos Open Tech | MIT / CC0 | Translation for covered pairs (e.g. en→fr, en→es) |

**Important — NLLB-200 is non-commercial.** If you use LiveTranslate in a
commercial product or paid service, you are responsible for complying with
Meta's CC-BY-NC-4.0 license for the NLLB-200 model, or for replacing it
with a commercially licensed alternative.

## Software libraries

| Library | License |
|---|---|
| [faster-whisper](https://github.com/SYSTRAN/faster-whisper) / [CTranslate2](https://github.com/OpenNMT/CTranslate2) | MIT |
| [Argos Translate](https://github.com/argosopentech/argos-translate) | MIT / CC0 |
| [Transformers](https://github.com/huggingface/transformers) | Apache-2.0 |
| [PyTorch](https://pytorch.org) | BSD-3-Clause |
| [sounddevice](https://github.com/spatialaudio/python-sounddevice) / PortAudio | MIT |
| [NumPy](https://numpy.org) | BSD-3-Clause |
| [Electron](https://www.electronjs.org) (Studio panel only) | MIT |
| [SentencePiece](https://github.com/google/sentencepiece) | Apache-2.0 |

DaVinci Resolve and the Workflow Integration API are products of
Blackmagic Design. This project is not affiliated with or endorsed by
Blackmagic Design, OpenAI, Meta, or any of the projects above.
