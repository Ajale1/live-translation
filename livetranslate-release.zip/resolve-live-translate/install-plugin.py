#!/usr/bin/env python3
"""Installer for the LiveTranslate WORKFLOW INTEGRATION plugin.

This is the 'real plugin' variant: it appears inside DaVinci Resolve under
  Workspace ▸ Workflow Integrations ▸ LiveTranslate
with its own panel window.

Requirements: DaVinci Resolve STUDIO (Workflow Integrations are not
available in the free edition), Windows or macOS, Node.js/npm, Python 3.9+.

Usage:
    python3 install-plugin.py

Steps performed:
  1. Python deps + models into ~/.livetranslate (same engine as the script
     version — shared, installed once).
  2. Copy the plugin (workflow-plugin/ + the livetranslate package) into
     Resolve's 'Workflow Integration Plugins' folder.
  3. npm install (Electron) inside the installed plugin.
  4. Copy WorkflowIntegration.node from Resolve's developer examples into
     the plugin so it can talk to the Resolve API.
"""

import glob
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PLUGIN_SRC = os.path.join(HERE, "workflow-plugin")
PKG_SRC = os.path.join(HERE, "livetranslate")


def plugins_dir() -> str:
    if sys.platform == "darwin":
        return "/Library/Application Support/Blackmagic Design/DaVinci Resolve/Workflow Integration Plugins"
    if sys.platform.startswith("win"):
        return os.path.join(
            os.environ.get("PROGRAMDATA", r"C:\ProgramData"),
            "Blackmagic Design", "DaVinci Resolve", "Support",
            "Workflow Integration Plugins",
        )
    sys.exit("Workflow Integration plugins are only supported by Resolve on Windows and macOS.\n"
             "On Linux, use the script version: python3 dist/LiveTranslate.py")


def wi_node_candidates():
    """Places Resolve ships WorkflowIntegration.node."""
    pats = []
    if sys.platform == "darwin":
        pats = [
            "/Applications/DaVinci Resolve/DaVinci Resolve.app/Contents/Resources/Developer/Workflow Integrations/**/WorkflowIntegration.node",
            "/Library/Application Support/Blackmagic Design/DaVinci Resolve/Developer/Workflow Integrations/**/WorkflowIntegration.node",
        ]
    elif sys.platform.startswith("win"):
        pf = os.environ.get("PROGRAMFILES", r"C:\Program Files")
        pd = os.environ.get("PROGRAMDATA", r"C:\ProgramData")
        pats = [
            os.path.join(pf, "Blackmagic Design", "DaVinci Resolve", "Developer", "Workflow Integrations", "**", "WorkflowIntegration.node"),
            os.path.join(pd, "Blackmagic Design", "DaVinci Resolve", "Support", "Developer", "Workflow Integrations", "**", "WorkflowIntegration.node"),
        ]
    for pat in pats:
        for hit in glob.glob(pat, recursive=True):
            return hit
    return None


def step(msg):
    print(f"\n==> {msg}")


def main():
    # 1. shared Python engine (deps + models) ---------------------------------
    step("Setting up the Python engine (deps + models, shared with the script version)")
    sys.path.insert(0, HERE)
    from livetranslate.bootstrap import run_setup_steps, setup_complete

    if setup_complete():
        print("    already set up — skipping.")
    else:
        run_setup_steps(lambda m: print("    " + m), script_path=None)

    # 2. copy plugin ----------------------------------------------------------
    dst_root = plugins_dir()
    dst = os.path.join(dst_root, "LiveTranslate")
    step(f"Installing plugin to {dst}")
    try:
        os.makedirs(dst_root, exist_ok=True)
        if os.path.isdir(dst):
            shutil.rmtree(dst)
        shutil.copytree(PLUGIN_SRC, dst)
    except PermissionError:
        sys.exit(
            f"Permission denied writing to {dst_root}.\n"
            "Re-run with elevated rights (macOS: sudo python3 install-plugin.py, "
            "Windows: run from an Administrator prompt)."
        )
    shutil.copytree(PKG_SRC, os.path.join(dst, "livetranslate"))
    print("    plugin files copied (incl. livetranslate engine package).")

    # 3. npm install ----------------------------------------------------------
    step("Installing Electron (npm install)")
    npm = shutil.which("npm") or shutil.which("npm.cmd")
    if not npm:
        sys.exit("npm not found. Install Node.js from https://nodejs.org and re-run.")
    subprocess.check_call([npm, "install", "--no-audit", "--no-fund"], cwd=dst)

    # 4. WorkflowIntegration.node --------------------------------------------
    step("Locating WorkflowIntegration.node")
    node_mod = wi_node_candidates()
    if node_mod:
        shutil.copy2(node_mod, os.path.join(dst, "WorkflowIntegration.node"))
        print(f"    copied from {node_mod}")
    else:
        print(
            "    NOT FOUND automatically. The plugin will still run, but cannot\n"
            "    push SRTs into the timeline until you copy WorkflowIntegration.node\n"
            "    from Resolve's 'Developer/Workflow Integrations' examples folder\n"
            f"    into: {dst}"
        )

    step("Done!")
    print(
        "\nRestart DaVinci Resolve (Studio), then open:\n"
        "  Workspace ▸ Workflow Integrations ▸ LiveTranslate\n"
        "\nNot on Studio? Use the script version instead:\n"
        "  python3 dist/LiveTranslate.py   (installs itself into Workspace ▸ Scripts)"
    )


if __name__ == "__main__":
    main()
