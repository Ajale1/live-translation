@echo off
REM LiveTranslate - double-click launcher/installer for FREE DaVinci Resolve (Windows).
REM First run sets everything up by itself; later runs open the caption window.
title LiveTranslate (free Resolve version)
cd /d "%~dp0"
echo ===============================================
echo   LiveTranslate (free Resolve version, Windows)
echo ===============================================
echo.

set PYCMD=python
where python >nul 2>nul
if errorlevel 1 (
  set PYCMD=py
  where py >nul 2>nul
  if errorlevel 1 (
    echo Python is not installed.
    echo Get it from https://www.python.org/downloads/
    echo IMPORTANT: tick "Add Python to PATH" during install, then run this again.
    pause
    exit /b 1
  )
)

if exist "dist\LiveTranslate.py" (
  %PYCMD% "dist\LiveTranslate.py"
) else (
  %PYCMD% "LiveTranslate.py"
)

echo.
echo Window closed. After the FIRST successful setup, LiveTranslate also
echo appears inside Resolve: Workspace ^> Scripts ^> LiveTranslate
pause
