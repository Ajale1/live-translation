#!/bin/bash
# LiveTranslate — double-click launcher/installer for FREE DaVinci Resolve (macOS).
# First run sets everything up by itself; later runs just open the caption window.
# If macOS blocks this file: right-click it -> Open -> Open.

cd "$(dirname "$0")"
clear
echo "==============================================="
echo "  LiveTranslate (free Resolve version, macOS)"
echo "==============================================="
echo

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is not installed."
  echo "Get it from https://www.python.org/downloads/ then run this again."
  read -r -p "Press Enter to close..."
  exit 1
fi

if [ -f "dist/LiveTranslate.py" ]; then
  python3 "dist/LiveTranslate.py"
else
  python3 "LiveTranslate.py"
fi

echo
echo "Window closed. After the FIRST successful setup, LiveTranslate also"
echo "appears inside Resolve: Workspace > Scripts > LiveTranslate"
read -r -p "Press Enter to close..."
