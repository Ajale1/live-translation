#!/usr/bin/env python3
"""LiveTranslate for DaVinci Resolve.

Real-time English transcription with instant French + Spanish translation,
displayed live in a caption window, exportable as SRT, and insertable into
the current Resolve timeline as subtitles.

Run from Resolve:  Workspace ▸ Scripts ▸ LiveTranslate
Run standalone:    python3 LiveTranslate.py
                   (enable DaVinci Resolve ▸ Preferences ▸ System ▸ General ▸
                    External scripting using: Local, to push SRTs into the
                    timeline)
"""

import os
import sys

# Make the bundled 'livetranslate' package importable regardless of where
# Resolve copied this script. install.py places the package either next to
# this file or in ~/.livetranslate/lib.
_here = os.path.dirname(os.path.abspath(__file__))
for candidate in (_here, os.path.join(os.path.expanduser("~"), ".livetranslate", "lib")):
    if os.path.isdir(os.path.join(candidate, "livetranslate")) and candidate not in sys.path:
        sys.path.insert(0, candidate)

from livetranslate.config import load_config  # noqa: E402
from livetranslate.ui import CaptionApp  # noqa: E402


def main():
    cfg = load_config()
    # `resolve` is injected as a global when launched from Resolve's
    # Scripts menu; standalone we let the bridge connect on its own.
    injected = globals().get("resolve")
    app = CaptionApp(cfg, resolve=injected)
    app.run()


if __name__ == "__main__" or globals().get("resolve") is not None:
    main()
