# Announcement kit

Fill in [LINK] with your GitHub repo URL before posting.

---

## Reddit post — r/davinciresolve

**Title:** I built a free plugin that live-translates speech into 30+
languages inside Resolve (incl. Hausa, Yoruba, Swahili) — captions appear
as you talk

**Body:**

Hey editors — I'm Williams Ameh from Regent Films Studio. I built LiveTranslate, a free & open-source
plugin for DaVinci Resolve, and I'm giving it away.

What it does:

- Live captions: speak (or play audio) and it transcribes + translates in
  real time into as many languages as you pick — each language gets its own
  caption line.
- 30+ languages, including ones almost no tool covers: Hausa, Yoruba, Igbo,
  Swahili, Amharic, Somali, plus French, Spanish, Arabic, Portuguese,
  Chinese, Hindi and more.
- "Transcribe Timeline" button: renders your timeline's audio through the
  Resolve API and gives you frame-accurate translated subtitles for the
  whole edit.
- Exports one SRT per language and inserts them into your timeline with one
  click.
- 100% local & offline after setup — no API keys, no subscription, your
  audio never leaves your machine.

Works with free Resolve (Scripts menu) and Studio (native Workflow
Integration panel). macOS / Windows / Linux (script version).

Download + install guide: [LINK]

It's free forever. It's free forever — if it saves you time, star the repo and share it. And if you'd rather have Regent Films Studio subtitle your videos for you, contact details are in the

---

## Blackmagic forum post

**Title:** [Free plugin] LiveTranslate — real-time multilingual captions +
timeline subtitling (30+ languages)

Same body as Reddit, slightly more formal; mention it uses the official
Workflow Integration API on Studio and the Scripts API on free Resolve,
and link ATTRIBUTIONS.md for the model licenses.

---

## X / Twitter thread

1/ I built a FREE plugin for DaVinci Resolve that live-translates speech
into 30+ languages — while you're talking. Watch it caption English into
Yoruba, French and Swahili at the same time 👇 [demo video]

2/ It runs 100% on your computer. No subscription, no API keys, no upload.
Whisper for speech, open translation models for text.

3/ It also transcribes your whole timeline with frame-accurate timestamps
and drops the subtitles straight onto your tracks. One SRT per language.

4/ African languages are first-class citizens: Hausa, Yoruba, Igbo,
Swahili, Amharic, Somali, Shona, Lingala. Nollywood editors, this one's
for you.

5/ Free & open source, forever: [LINK]
If it helps you, share it and star the repo ⭐

---

## Demo video script (60–90 seconds, screen recording)

1. (0–10s) Hook — face or voiceover: "This free plugin live-translates
   your voice into Yoruba, French and Swahili — inside DaVinci Resolve.
   Watch."
2. (10–30s) Screen: the panel open, press ▶ Start, speak one sentence in
   English. The caption rows fill in live, language by language. Zoom on
   the Yoruba line.
3. (30–50s) Click ⏲ Transcribe Timeline on a short edit. Show the progress
   status, then the finished SRT list. Click "SRT → Timeline (YO)" — the
   subtitle track appears on the timeline. Play a few seconds with
   subtitles visible.
4. (50–70s) Show the language picker: type "hau…" → Hausa appears, add it
   as a chip, Apply. "Thirty-plus languages. Everything runs offline on
   your machine."
5. (70–90s) Close: "Free and open source — link in the description. If you
   want your videos subtitled for you, my contact is there too."

Recording tips: macOS screen recording (Cmd+Shift+5), record Resolve
full-screen, panel on the right; speak clearly; do one rehearsal run first
so the models are warm and captions appear fast.
