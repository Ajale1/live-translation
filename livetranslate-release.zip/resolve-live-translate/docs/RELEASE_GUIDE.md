# How to publish LiveTranslate on GitHub (beginner-friendly)

Follow these steps once, on your Mac, in order. No prior GitHub experience
needed.

## 1. Create the account and repository

1. Go to https://github.com and sign up (free) if you don't have an account.
2. Click the "+" (top right) ▸ "New repository".
3. Repository name: `livetranslate-resolve`
4. Description: `Free real-time transcription + translation plugin for
   DaVinci Resolve — live captions in 30+ languages incl. Hausa, Yoruba,
   Swahili. SRT export & timeline insertion.`
5. Keep it Public. Do NOT tick "Add a README" (you already have one).
6. Click "Create repository".

## 2. Upload the project

Easiest way (no git commands):

1. On the new repo page, click "uploading an existing file".
2. In Finder, open your `resolve-live-translate` folder, select EVERYTHING
   inside it (Cmd+A), and drag it onto the GitHub upload page.
   - Skip the `dist` folder for now if the uploader complains; you'll attach
     `dist/LiveTranslate.py` to the Release in step 3 instead.
3. Commit message: `LiveTranslate v1.2.2` ▸ click "Commit changes".

## 3. Create the first Release (what users actually download)

1. On the repo page: right sidebar ▸ "Releases" ▸ "Create a new release".
2. Tag: `v1.2.2` (click "Create new tag on publish").
3. Title: `LiveTranslate 1.2.2 — live translated captions for DaVinci Resolve`
4. Description: paste the "1.2.2 / 1.2.0" sections from CHANGELOG.md, plus:
   - Free Resolve users → download `LiveTranslate.py` below, run
     `python3 LiveTranslate.py` once.
   - Studio users → download the Source code zip, run
     `python3 install-plugin.py`.
5. Drag `dist/LiveTranslate.py` into the "Attach binaries" box.
6. Click "Publish release".

## 4. Before you announce — fill in your links

Search the project for `[YOUR-DONATION-LINK]` and `[YOUR-CONTACT-LINK]`
(they are in README.md) and replace them with your real links:

- Donation: create a page at https://buymeacoffee.com or
  https://ko-fi.com (5 minutes, free) — this is how a free tool earns.
- Contact: your email, X/Instagram profile, or a simple portfolio page —
  wherever "hire me to subtitle your videos" should lead.

Also set them in the plugin panel: `workflow-plugin/renderer/index.html`,
the `id="credit"` link (`href="#"` → your link).

## 5. Announce it

Ready-made posts are in `docs/ANNOUNCEMENT.md`. Post to:

- r/davinciresolve and r/VideoEditing (Reddit)
- The Blackmagic Design forum (Resolve section)
- X/Twitter and TikTok with the demo video (script in the same file)
- Nollywood / African creator communities you're part of — this is your
  strongest differentiator; lead with the Yoruba/Hausa/Swahili demo.

## 6. After launch

- Watch the repo's "Issues" tab — answer questions, fix what breaks.
- Each fix: update CHANGELOG.md, run `python3 build.py`, create a new
  Release with the new version number and the fresh `dist/LiveTranslate.py`.
- Users who ask "can you just do the subtitles for me?" — that's your
  paid-service funnel. Quote per video-minute per language.
