#!/usr/bin/env python3
"""LiveTranslate installer for DaVinci Resolve.

What it does:
  1. Installs Python dependencies (faster-whisper, argostranslate,
     sounddevice, numpy) into the interpreter you run it with.
  2. Downloads the Argos en->fr and en->es translation packages and the
     Whisper model so first launch is instant and fully offline.
  3. Copies LiveTranslate.py into Resolve's 'Utility' scripts folder and
     the 'livetranslate' package into ~/.livetranslate/lib.

IMPORTANT: run this with the SAME Python that DaVinci Resolve uses
(Resolve ▸ Preferences ▸ System ▸ General shows the Python it found;
on most systems that is the default 'python3').

    python3 install.py
"""

import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

REQUIREMENTS = [
    "numpy",
    "sounddevice",
    "faster-whisper",
    "argostranslate",
]


def resolve_scripts_dir() -> str:
    if sys.platform == "darwin":
        base = os.path.expanduser(
            "~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Scripts/Utility"
        )
    elif sys.platform.startswith("win"):
        base = os.path.join(
            os.environ.get("APPDATA", ""),
            "Blackmagic Design",
            "DaVinci Resolve",
            "Support",
            "Fusion",
            "Scripts",
            "Utility",
        )
    else:
        base = os.path.expanduser(
            "~/.local/share/DaVinciResolve/Fusion/Scripts/Utility"
        )
    return base


def step(msg):
    print(f"\n==> {msg}")


def main():
    step(f"Installing Python dependencies into {sys.executable}")
    subprocess.check_call(
        [sys.executable, "-m", "pip", "install", "--upgrade", *REQUIREMENTS]
    )

    step("Downloading Argos translation packages (en->fr, en->es)")
    import argostranslate.package as apkg

    apkg.update_package_index()
    installed = {(p.from_code, p.to_code) for p in apkg.get_installed_packages()}
    for to_code in ("fr", "es"):
        if ("en", to_code) in installed:
            print(f"    en->{to_code}: already installed")
            continue
        pkg = next(
            p
            for p in apkg.get_available_packages()
            if p.from_code == "en" and p.to_code == to_code
        )
        print(f"    en->{to_code}: downloading…")
        apkg.install_from_path(pkg.download())

    step("Pre-downloading the Whisper model (small.en, int8)")
    from faster_whisper import WhisperModel

    WhisperModel("small.en", device="auto", compute_type="int8")
    print("    model cached.")

    step("Installing the plugin into DaVinci Resolve")
    scripts_dir = resolve_scripts_dir()
    os.makedirs(scripts_dir, exist_ok=True)
    shutil.copy2(os.path.join(HERE, "LiveTranslate.py"), scripts_dir)
    print(f"    copied LiveTranslate.py -> {scripts_dir}")

    lib_dir = os.path.join(os.path.expanduser("~"), ".livetranslate", "lib")
    os.makedirs(lib_dir, exist_ok=True)
    dst_pkg = os.path.join(lib_dir, "livetranslate")
    if os.path.isdir(dst_pkg):
        shutil.rmtree(dst_pkg)
    shutil.copytree(os.path.join(HERE, "livetranslate"), dst_pkg)
    print(f"    copied package     -> {dst_pkg}")

    step("Done!")
    print(
        "\nOpen DaVinci Resolve and run:  Workspace ▸ Scripts ▸ LiveTranslate\n"
        "To push subtitles into the timeline while running standalone, enable\n"
        "Preferences ▸ System ▸ General ▸ 'External scripting using: Local'."
    )


if __name__ == "__main__":
    main()
