# Changelog

## 1.3.0 — 2026-07-10
- Review / Edit mode in the Studio panel: after a live session or timeline
  transcription, open an editable transcript — correct any word in the
  source, hit Re-translate to update every target language from the fixed
  text, or hand-edit individual translations. Exports and timeline pushes
  use the corrected text.
- Fixed: live-session captions are now kept after Stop (export after Stop
  works in the panel).

## 1.2.3 — 2026-07-10
- Transcribe Timeline: detect the render format/codec supported by the
  user's Resolve version at runtime (fixes 'unknown render codec/format
  combination' error on some Resolve versions).

## 1.2.2 — 2026-07-10
- Pin numpy below 2.0 everywhere (fixes "dtype size changed / binary
  incompatibility" crash after installing the NLLB engine).

## 1.2.1 — 2026-07-10
- Pin transformers >= 4.53 and huggingface_hub >= 0.31 (fixes
  "404 Client Error: chat_template.jinja does not exist" when downloading
  the NLLB-200 model).

## 1.2.0 — 2026-07-10
- Multilingual: choose any spoken source language and translate into one or
  MANY targets simultaneously (30+ languages).
- African languages added: Hausa, Yoruba, Igbo (target-only), Swahili,
  Amharic, Somali, Shona, Lingala, Afrikaans, Malagasy — powered by a new
  per-language translation router (Argos where available, NLLB-200 fallback,
  installed automatically on first use).
- Searchable language pickers in both UIs; selection remembered across
  sessions.
- One SRT per language; dynamic "SRT → Timeline" buttons.
- "Transcribe Timeline": renders the current timeline's audio through the
  Resolve API and produces frame-accurate, translated subtitles (offline
  mode, faster than real-time).

## 1.1.0 — 2026-07-09
- Workflow Integration plugin (native Resolve Studio panel, Electron) with
  a JSON-stdio Python backend.
- Headless backend mode (`python -m livetranslate.headless`).

## 1.0.0 — 2026-07-09
- First release: real-time EN→FR/ES live captions (script version),
  self-installing single-file distribution, SRT export, SRT→timeline
  insertion.
